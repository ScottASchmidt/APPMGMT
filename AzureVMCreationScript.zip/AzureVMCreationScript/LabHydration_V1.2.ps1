﻿### Setting Launch Params
param(
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$AzureUserName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$TenantName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][ValidateSet("True", "False")][String]$HighRes
)

### Enable-AzureRMAlias allows for Legacy AzureRM Cmdlets to be used
Enable-AzureRMAlias

#$ErrorActionPreference = "SilentlyContinue"
$CurrentDirectory = $PSScriptRoot
$TitleICO = New-Object system.drawing.icon ("$CurrentDirectory\MSLogo.ico")

### Always Add These to PowerShell Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationFramework

### If HighRes Screen is set the form multiplier will be reset to accomodate a larger size
If($HighRes -eq "True")
{
    $Global:XMultiplier=2
    $Global:yMultiplier=2
}
Else
{
    $Global:XMultiplier=1
    $Global:yMultiplier=1
}



### Setting Up PowerShell Form
$Global:Form = New-Object System.Windows.Forms.Form    
$Global:Form.Size = New-Object System.Drawing.Size((1024*$Global:XMultiplier),(800*$Global:yMultiplier))  
$Global:Form.Text = "Lab Hydration Utility"  
$Global:ClientName = "Microsoft"
$Global:Form.BackColor = "#00a3ee"
$Global:Form.Icon = $TitleICO

### Authenticating to Graph / Tenant
function Get-AuthToken
{
    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )

    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    $tenant = $userUpn.Host

    Write-Host "Checking for AzureAD module..."

    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($AadModule -eq $null)
    {
        Write-Host "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }

    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    $resourceAppIdURI = "https://graph.microsoft.com"
    $authority = "https://login.microsoftonline.com/$Tenant"

    try {
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
        # https://msdn.microsoft.com/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
        # If the accesstoken is valid then create the authentication header
        if ($authResult.AccessToken) {
            # Creating header for Authorization token
            $authHeader = @{
                'Content-Type' = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn' = $authResult.ExpiresOn
            }
            return $authHeader
        }
        else {
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
        }
    }
    catch {
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    }   
}

### Connecting to Azure
$Global:authToken = Get-AuthToken -User $AzureUserName

######### Creating Form Objects #########
### Creating Label Objects
$NewRGLabel = New-Object System.Windows.Forms.Label
$NewVNetLabel = New-Object System.Windows.Forms.Label
$NewSubnetLabel = New-Object System.Windows.Forms.Label
$NewRGNameLabel = New-Object System.Windows.Forms.Label
$NewVNetNameLabel = New-Object System.Windows.Forms.Label 
$NewVNetDescriptionLabel = New-Object System.Windows.Forms.Label
$NewSubnetDescriptionLabel = New-Object System.Windows.Forms.Label
$NewSubnetNameLabel = New-Object System.Windows.Forms.Label
$NewDCCBLabel = New-Object System.Windows.Forms.Label
$NewMSCBLabel = New-Object System.Windows.Forms.Label
$NewWSCBLabel = New-Object System.Windows.Forms.Label
$NewDCCompNameLabel = New-Object System.Windows.Forms.Label
$NewMSCompNameLabel = New-Object System.Windows.Forms.Label
$NewWSCompNameLabel = New-Object System.Windows.Forms.Label
$NewDCCountLabel = New-Object System.Windows.Forms.Label
$NewMSCountLabel = New-Object System.Windows.Forms.Label
$NewWSCountLabel = New-Object System.Windows.Forms.Label
$NewDCImageLabel = New-Object System.Windows.Forms.Label
$NewMSImageLabel = New-Object System.Windows.Forms.Label
$NewWSImageLabel = New-Object System.Windows.Forms.Label
$NewDCMachineTypeLabel = New-Object System.Windows.Forms.Label
$NewMSMachineTypeLabel = New-Object System.Windows.Forms.Label
$NewWSMachineTypeLabel = New-Object System.Windows.Forms.Label

### Creating Drop Down Menu
$AzureSubscriptionsDropdown = New-Object System.Windows.Forms.ComboBox
$AzureResourceGroupDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualNetworkDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualSubnetDropdown = New-Object System.Windows.Forms.ComboBox
$AzureLocationDropdown = New-Object System.Windows.Forms.ComboBox
$AzureDMachineDropdown = New-Object System.Windows.Forms.ComboBox
$AzureBMachineDropdown = New-Object System.Windows.Forms.ComboBox
$AzureLocationDropDown = New-Object System.Windows.Forms.ComboBox
$NewVNetDropDown = New-Object System.Windows.Forms.ComboBox
$NewDCImageDropDown = New-Object System.Windows.Forms.ComboBox
$NewDCMachineTypeDropDown = New-Object System.Windows.Forms.ComboBox
$NewMSImageDropDown = New-Object System.Windows.Forms.ComboBox
$NewMSMachineTypeDropDown = New-Object System.Windows.Forms.ComboBox
$NewWSImageDropDown = New-Object System.Windows.Forms.ComboBox
$NewWSMachineTypeDropDown = New-Object System.Windows.Forms.ComboBox
$NewSubnetDropDown = New-Object System.Windows.Forms.ComboBox

### Creating Text Box Objects
$ResourceGroupNameTextBox = New-Object System.Windows.Forms.TextBox
$NewVNetNameTextBox = New-Object System.Windows.Forms.TextBox
$NewSubnetNameTextBox = New-Object System.Windows.Forms.TextBox
$NewDCCountTextBox = New-Object System.Windows.Forms.TextBox
$NewMSCountTextBox = New-Object System.Windows.Forms.TextBox
$NewWSCountTextBox = New-Object System.Windows.Forms.TextBox
$NewDCNameTextBox = New-Object System.Windows.Forms.TextBox
$NewMSNameTextBox = New-Object System.Windows.Forms.TextBox
$NewWSNameTextBox = New-Object System.Windows.Forms.TextBox

### Creating Buttons
$CreateNewRGButton = New-Object System.Windows.Forms.Button 
$VerifyNewRGButton = New-Object System.Windows.Forms.Button 
$CreateNewVNetButton = New-Object System.Windows.Forms.Button 
$VerifyNewVNetButton = New-Object System.Windows.Forms.Button 
$VerifyNewSubnetButton = New-Object System.Windows.Forms.Button
$CreateNewSubnetButton = New-Object System.Windows.Forms.Button
$VerifyNewDCButton = New-Object System.Windows.Forms.Button
$CreateNewDCButton = New-Object System.Windows.Forms.Button
$VerifyNewMSButton = New-Object System.Windows.Forms.Button
$CreateNewMSButton = New-Object System.Windows.Forms.Button
$VerifyNewWSButton = New-Object System.Windows.Forms.Button
$CreateNewWSButton = New-Object System.Windows.Forms.Button

### Creating Checkbox Objects
$NewRGCheckBox = new-object System.Windows.Forms.checkbox
$NewVnetCheckBox = new-object System.Windows.Forms.checkbox
$NewSubNetCheckBox = new-object System.Windows.Forms.checkbox
$NewDCCheckBox = New-object System.Windows.Forms.checkbox
$NewMSCheckBox = New-object System.Windows.Forms.checkbox
$NewWSCheckBox = New-object System.Windows.Forms.checkbox

######### Functions for Creating Form Objects #########

### Function to Create DropDown Menus
Function CreateDropDownMenus($DropdownObject,$PosX,$PosY,$BoxLen,$BoxHeight,$MenuHeight,$TextforFirstItem)
{
    $DropdownObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $DropdownObject.Size = new-object System.Drawing.Size($BoxLen,$BoxHeight)
    $DropdownObject.DropDownHeight = 300
    $DropdownObject.Enabled = $False
    $DropdownObject.Items.Add($TextforFirstItem)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
    $DropdownObject.BringToFront()
    $DropdownObject.Font = New-Object System.Drawing.Font("Lucida Console",(9*$XMultiplier),[System.Drawing.FontStyle]::Regular)
    $DropdownObject.show()
    $Form.Controls.Add($DropdownObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $CheckBoxObject.enabled = $false
    $CheckBoxObject.margin = "0,0,0,0"
    $CheckBoxObject.show()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Text Labels
Function CreateTextBoxLabel($TextBoxLabel,$PosX,$PosY,$BoxLen,$BoxHeight,$Title)
{
    $TextBoxLabel.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxLabel.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxLabel.Text = $Title
    $TextBoxLabel.BringToFront()
    $TextBoxLabel.Show()
    #$TextBoxLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $Global:form.Controls.Add($TextBoxLabel)
}

### Function to Create Text Box 
Function CreateTextBoxObject($TextBoxObject,$PosX,$PosY,$BoxLen,$BoxHeight)
{
    #Write-host $BoxHeight
    $TextBoxObject.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxObject.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxObject.BringToFront()
    $TextBoxObject.show()
    $Global:form.Controls.Add($TextBoxObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.show()
    $CheckBoxObject.BringToFront()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Buttons
Function CreateButton($ButtonObject,$PosX,$PosY,$ButtonLen,$ButtonHeight,$ButtonText,$Type)
{  
    $ButtonObject.Location = New-Object System.Drawing.Size($PosX,$PosY) 
    $ButtonObject.Size = New-Object System.Drawing.Size($ButtonLen,$ButtonHeight) 
    #$ButtonObject.Font = $Global:High_DPIScale_Font
    $ButtonObject.Text = $ButtonText
    $ButtonObject.BringToFront()
    $ButtonObject.Backcolor = "#7eb801"
    #$ButtonObject.ForeColor = "#FFFFFF"
    $ButtonObject.FlatStyle = [system.windows.forms.FlatStyle]::Flat
    $ButtonObject.FlatAppearance.BorderColor = [System.Drawing.Color]::Gray
    $ButtonObject.FlatAppearance.BorderSize = (1*$XMultiplier)
    $ButtonObject.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $ButtonObject.show()
    If($Type -eq "Validate")
    {
        $ValidationButtonImage = [system.drawing.image]::FromFile("$CurrentDirectory\ResizedValidate.png")
        $ButtonObject.image = $ValidationButtonImage
    }
    If($Type -eq "Create")
    {
        $CreateButtonImage = [system.drawing.image]::FromFile("$CurrentDirectory\ResizedCreate.png")
        $ButtonObject.image = $CreateButtonImage
    }
    $ButtonObject.font = New-Object System.Drawing.Font("Calibri",(9*$XMultiplier),[System.Drawing.FontStyle]::Regular)
    $Form.Controls.Add($ButtonObject)
}

####### Populating DropdownMenus #######
### Populating Resource Group DropDown -This change is initiated from a change in the subscription dropdown
Function SortDropDownMenu($DropdownObject)
{
    $DropdownObject.Enabled = $true
    $DropdownObject.Sorted = $true
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function ClearDropDownMenu($DropdownObject,$FirstLineText)
{
    $DropdownObject.Items.Clear()
    $DropdownObject.Items.Add($FirstLineText)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function SubscriptionDropDownChange
{
    If($AzureSubscriptionsDropdown.SelectedIndex -gt 0)
    {
        $NewRGCheckBox.Enabled = $True
        $Global:SubscriptionName = $AzureSubscriptionsDropdown.SelectedItem
        Select-AzSubscription -subscription $Global:SubscriptionName

        ### Populating Azure Resource Groups
        ClearDropDownMenu $AzureResourceGroupDropdown "- Choose Azure Resource Group -"

        $AzureResourceGroups = Get-AZResourceGroup |select resourcegroupname,location
        ForEach($ResourceGroup in $AzureResourceGroups)
        {
            $ResourceGroupText = $ResourceGroup.ResourceGroupName + " (" + $ResourceGroup.Location + ")"
            $AzureResourceGroupDropdown.Items.Add($ResourceGroupText)
        }
        SortDropDownMenu $AzureResourceGroupDropdown
    }
    Else
    {
        $NewRGCheckBox.Enabled = $false
        ClearDropDownMenu $AzureResourceGroupDropdown "- Choose Azure Resource Group -"
    }
}


### Populating VNet Dropdown - Based on Resource Group Selection Changes
Function ResourceGroupChange
{
    If($AzureResourceGroupDropdown.SelectedIndex -gt 0)
    {
        $NewVnetCheckBox.Enabled = $True
        [string]$ResourceGroup = $AzureResourceGroupDropdown.SelectedItem
        $LocationCount = $ResourceGroup.IndexOf(' (' )
        #$ResourceLocationLength = $ResourceGroup.Length - ($LocationCount + 11)
        $Global:ResourceGroupName = $ResourceGroup.Substring(0,$LocationCount)

        ### Populating Network Dropdown Info
        ClearDropDownMenu $AzureVirtualNetworkDropdown "- Choose Azure Virtual Network -"
         
        $AzureVirtualNetworks = Get-AzVirtualNetwork -WarningAction SilentlyContinue -ResourceGroupName $Global:ResourceGroupName
        ForEach($Network in $AzureVirtualNetworks)
        {
           $AzureVirtualNetworkDropdown.Items.Add($Network.Name)
        }
        SortDropDownMenu $AzureVirtualNetworkDropdown
        ### Setting this variable to track location change between functions
        #$Global:LastCheckResouceGroupLocation = $Global:ResourceGroupLocation
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualNetworkDropdown "- Choose Azure Virtual Network -"
    }
}

### VNet Network
Function NetworkGroupChange
{
    IF($AzureVirtualNetworkDropdown.SelectedIndex -gt 0)
    {
        $NewSubNetCheckBox.Enabled = $True
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
        $AzureVirtualNetworks = Get-AzVirtualNetwork
        ForEach($Network in $AzureVirtualNetworks)
        {
            $AZResourceGroup = $Network.ResourceGroupName 
            $AZResrouceName = $Network.Name
            If($AZResrouceName -eq $AzureVirtualNetworkDropdown.SelectedItem)
            {
                $Location = $Network.Location
                $VNetPreFix = $Network.AddressSpace.AddressPrefixes
                #$VNET = Get-AzVirtualNetwork -ResourceGroupName $AZResourceGroup -Name $AZResrouceName
                $SubnetList = $Network.Subnets
                ForEach($Prefix in $SubnetList)
                {
                    $SubnetText = $Prefix.Name + " (" + $Prefix.AddressPrefix + ")"
                    $AzureVirtualSubnetDropdown.Items.Add($SubnetText)
                }
            }
        }
        SortDropDownMenu $AzureVirtualSubnetDropdown
        ### Retrieving VM Types from the Azure Data Center specified in the Network Location
        GetAZMachinesTypes $Location
        GetGalleryImages $Location
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
    }
}

### Creating Windows Gallery Images Lists
Function GetGalleryImages($Location)
{
    $Global:DesktopImageArray = @()
    $Global:ServerImageArray = @()
    $Win10Image = Get-AzVMImageSku -Location $Location -PublisherName MicrosoftWindowsDesktop -Offer Windows-10 | Where-Object{$_.Skus -like "*ent-g2"} | select skus
    $Win11Image = Get-AzVMImageSku -Location $Location -PublisherName MicrosoftWindowsDesktop -Offer Windows-11 | Where-Object{$_.Skus -like "*ent"} | select skus
    ### Contains 2012,2012R2,206,2019
    $Server201xImage = Get-AzVMImageSku -Location $Location -PublisherName MicrosoftWindowsserver -Offer WindowsServer | Where-Object{$_.Skus -like "*datacenter-gensecond"} | select skus
    ### Contains Server 2022 and forward images
    $Server202xImage = Get-AzVMImageSku -Location $Location -PublisherName MicrosoftWindowsserver -Offer WindowsServer | Where-Object{$_.Skus -like "*datacenter-g2"} | select skus
    ForEach($SKU in $Win10Image){$Global:DesktopImageArray += $SKU.Skus}
    ForEach($SKU in $Win11Image){$Global:DesktopImageArray += $SKU.Skus}
    ForEach($SKU in $Server201xImage){$Global:ServerImageArray += $SKU.Skus}
    ForEach($SKU in $Server202xImage){$Global:ServerImageArray += $SKU.Skus}
}
### Getting Azure Machine Types
Function GetAZMachinesTypes($Location)
{
    $AZMachineArray = Get-AzVmSize -Location $Location
    $Global:DClassTable = @{}
    $Global:BClassTable = @{}
    ForEach($MachineType in $AZMachineArray)
    {
        ### Creating D Class Machine Array
        IF($MachineType.Name -like "Standard_D*V5" -or $MachineType.Name -like "Standard_D*V2")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
             $Global:DClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }

        ### Creating B Class Machine Array
        IF($MachineType.Name -like "Standard_B*")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
            $Global:BClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }
    }
}

### Getting Azure DataCenter Locations
Function GetAZLocations
{
    CreateDropDownMenus $AzureLocationDropDown (20*$XMultiplier) (220*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose AZ DataCenter Location -"
    $AzureLocationDropDown.Hide()
    $AZLocationArray = Get-AzLocation | Sort-Object DisplayName
    $Global:LocationTable = @{}
    ForEach($GeoLocation in $AZLocationArray)
    {
        [string]$Name = $GeoLocation.DisplayName
        [string]$LocationString = $GeoLocation.Location
        $Global:LocationTable += @{$Name = [PSCustomObject]@{LOCATION=$LocationString}}
        $AzureLocationDropDown.Items.Add($Name)
        SortDropDownMenu $AzureLocationDropDown
    }
    Write-Host $Global:LocationTable["West US 2"].LOCATION
    #Write-Host $BClassTable.Name
}

#### Creating New ResourceGroup form Objects - From CheckBox Click
Function CreateNewRGObects($checkstate)
{
    If($checkstate -eq "Checked")
    {
        $AzureVirtualNetworkDropdown.Enabled = $False
        $NewVnetCheckBox.Enabled = $False
        $AzureResourceGroupDropdown.Enabled = $false
        CreateTextBoxLabel $NewRGNameLabel (20*$XMultiplier) (160*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Resource Group Name"
        CreateTextBoxObject $ResourceGroupNameTextBox (20*$XMultiplier) (180*$yMultiplier) (300*$XMultiplier) (20*$XMultiplier)
        CreateButton $VerifyNewRGButton (20*$XMultiplier) (260*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Verify Resource Group" "Validate"
        CreateButton $CreateNewRGButton (20*$XMultiplier) (310*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Create Resource Group" "Create"
        $CreateNewRGButton.Enabled = $False
        $CreateNewRGButton.BackColor = "#aba7a7"
        $NewRGNameLabel.Show()
        $ResourceGroupNameTextBox.show()
        $AzureLocationDropDown.Enabled = $true
        $AzureLocationDropDown.Show()
        $CreateNewRGButton.Show()
        $VerifyNewRGButton.Show()
    }
    Else
    {
        $NewRGNameLabel.hide()
        $ResourceGroupNameTextBox.Clear()
        $ResourceGroupNameTextBox.Hide()
        $AzureLocationDropDown.Enabled = $false
        $AzureLocationDropDown.Hide()
        $AzureLocationDropDown.SelectedIndex[0]
        $AzureResourceGroupDropdown.Enabled = $true
        $CreateNewRGButton.hide()
        $VerifyNewRGButton.hide()
    } 

}

Function VerifyRG
{
    ### Resetting Items to enabled state
    $ResourceGroupNameTextBox.Enabled = $true
    $CreateNewRGButton.Enabled = $False
    $VerifyNewRGButton.Enabled = $True

    $ValidationPassed = $False
    If($ResourceGroupNameTextBox.Text -NE "")
    {
        If(Get-AzResourceGroup -Name $ResourceGroupNameTextBox.Text -ErrorAction SilentlyContinue)
        {
            
            [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " already exists. Press OK to try again.",'Resource Group Validation','OK','Error')
        }
        else
        {
            ### Checking for special Characters and Spaces
            If(($ResourceGroupNameTextBox.Text -match '[^a-zA-Z0-9^-]') -eq $True)
            {
                [System.Windows.MessageBox]::Show("The Resource Group cannot contain spaces or special characters.`nPress OK to try again.",'Location Validation','OK','Error')
            }
            Else
            {
                If($AzureLocationDropDown.SelectedIndex -eq 0)
                {
                    $LocationSelectionMsgText = "Location is not selected, press OK to continue and select a Location."
                    [System.Windows.MessageBox]::Show( $LocationSelectionMsgText,'Location Validation','OK','Error')
                }
                Else
                {
                    $LocationSelectionMsgText = "Verify that " + $AzureLocationDropDown.Text + " is the correct location."
                    $ValidationPassed = [System.Windows.MessageBox]::Show($LocationSelectionMsgText + "`nThe Resource Group " + $ResourceGroupNameTextBox.Text + " has passed Validation. Press Yes to Continue or No to Go Back",'Resource Group Validation','YesNo','Question')
                }
            }
        }
    }
    Else
    {
        [System.Windows.MessageBox]::Show("The Resource Group Name Field cannot be left bank. Press OK to try again.",'Resource Group Validation','OK','Error')
    }
    
    If($ValidationPassed -eq "Yes")
    {
        $VerifyNewRGButton.Enabled = $False
        $CreateNewRGButton.Enabled = $true
        $ResourceGroupNameTextBox.Enabled = $False
        $VerifyNewRGButton.BackColor = "#aba7a7"
        $CreateNewRGButton.BackColor = "#7eb801"
    }
    Else
    {
        $ResourceGroupNameTextBox.Enabled = $true
        $CreateNewRGButton.Enabled = $False
    }
}

Function CreateNewRG
{
    [String]$RGNameText = $ResourceGroupNameTextBox.Text

    New-AzResourceGroup -Name $RGNameText -Location $AzureLocationDropDown.Text
    If(Get-AzResourceGroup -Name $ResourceGroupNameTextBox.Text -ErrorAction SilentlyContinue)
    {
        $CreateRG = [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " has been successfully created.`nIf you are finished creating creating resource groups, press Yes to close form and continue or `npress No to create another resource Group.",'Resource Group Creation','YesNo','Question')
    }
    else
    {
        [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " failed to create. Press OK to try again.",'Resource Group Creation','Ok','Error')
        $ResourceGroupNameTextBox.Enabled = $true
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
    }

    If($CreateRG -eq "Yes")
    {
        SubscriptionDropDownChange
        $NewRGCheckBox.Checked = $False
        $ResourceGroupNameTextBox.Enabled = $true
        $ResourceGroupNameTextBox.Clear()
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
    }
    Else
    {
        $ResourceGroupNameTextBox.Enabled = $true
        $ResourceGroupNameTextBox.Clear()
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
        $AzureLocationDropDown.SelectedIndex = 0
        SubscriptionDropDownChange
        CreateNewRGObects "Checked"
    }
}

#### Creating New VNet form Objects - From CheckBox Click
Function CreateVNetObects($checkstate)
{
    If($checkstate -eq "Checked")
    {
        $AzureVirtualNetworkDropdown.Enabled = $False
        CreateTextBoxLabel $NewVNetNameLabel (340*$XMultiplier) (160*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Virtual Network Name"
        CreateTextBoxObject $NewVNetNameTextBox (340*$XMultiplier) (180*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateDropDownMenus $NewVNetDropDown (340*$XMultiplier) (250*$yMultiplier) (200*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose VNet Prefix -"
        CreateTextBoxLabel $NewVNetDescriptionLabel (340*$XMultiplier) (220*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Class B VNets are used for Simplicity"
        CreateButton $VerifyNewVNetButton (340*$XMultiplier) (290*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Verify New VNet" "Validate"
        CreateButton $CreateNewVNetButton (340*$XMultiplier) (340*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Create New VNet" "Create"
        $NewVNetNameLabel.Show()
        $NewVNetNameTextBox.Show()
        $NewVNetDropDown.Show()
        $NewVNetDescriptionLabel.Show()
        $VerifyNewVNetButton.Show()
        $CreateNewVNetButton.Show()
        $CreateNewVNetButton.Enabled = $False
        $CreateNewVNetButton.BackColor = "#aba7a7"
        $NewVNetDropDown.enabled = $true
        ### Retrieving Subnets to be used for duplicate checking when building the dropdown
        $VNetAddressList = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName).AddressSpace.AddressPrefixes
        #### Populatng dropdown menu
        $VNETCreateCheck = 1
        $VNETFirstOctet = 10
        DO
        {
            $VnetString = [string]$VNETFirstOctet + '.0.0.0/16'
            $Match = $false
            ForEach($Address in $VNetAddressList)
            {
                [String]$VNetFromArray = $Address
                If($VnetString -eq $VNetFromArray)
                {
                    $Match = $True
                    $VNETFirstOctet++
                }
            }
            If($Match -eq $false)
            {
                $NewVNetDropDown.Items.Add($VnetString)
                $VNETFirstOctet++
                $VNETCreateCheck++
            }            
        } Until ($VNETCreateCheck -gt 10)
        SortDropDownMenu $NewVNetDropDown
    }
    Else
    {
        $AzureVirtualNetworkDropdown.Enabled = $True
        $NewVNetDropDown.Items.Clear()
        $NewVNetNameLabel.Hide()
        $NewVNetNameTextBox.Hide()
        $NewVNetDropDown.Hide()
        $NewVNetDescriptionLabel.Hide()
        $VerifyNewVNetButton.Hide()
        $CreateNewVNetButton.Hide()
    } 
}

Function VerifyVNet
{
    ### Resetting Items to enabled state
    $NewVNetNameTextBox.Enabled = $true
    $CreateNewVNetButton.Enabled = $False
    $VerifyNewVNetButton.Enabled = $True

    $ValidationPassed = $False
    If($NewVNetNameTextBox.Text -NE "")
    {
        if(Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $NewVNetNameTextBox.Text -ErrorAction SilentlyContinue)
        {
            
            [System.Windows.MessageBox]::Show("The VNet " + $NewVNetNameTextBox.Text + " already exists. Press OK to try again.",'Virtual Network Validation','OK','Error')
        }
        else
        {
            ### Checking for special Characters and Spaces
            If(($NewVNetNameTextBox.Text -match '[^a-zA-Z0-9^-]') -eq $True)
            {
                [System.Windows.MessageBox]::Show("The VNet Name cannot contain spaces or special characters.`nPress OK to try again.",'Virtual Network Validation','OK','Error')
            }
            Else
            {
                If($NewVNetDropDown.SelectedIndex -eq 0)
                {
                    $VNetSelectionMsgText = "VNet Address Prefix is not selected, press OK to continue and select a VNet Address Prefix."
                    [System.Windows.MessageBox]::Show($VNetSelectionMsgText,'Virtual Network Validation','OK','Error')
                }
                Else
                {
                    $VNetSelectionMsgText = "Verify that " + $NewVNetDropDown.Text + " is the correct Address Prefix."
                    $ValidationPassed = [System.Windows.MessageBox]::Show($VNetSelectionMsgText + "`nThe Virtual Network " + $ResourceGroupNameTextBox.Text + " has passed Validation. Press Yes to Continue or No to Go Back",'Virtual Network Validation','YesNo','Question')
                }
            }
        }
    }
    Else
    {
        [System.Windows.MessageBox]::Show("The New VNet Group Name Field cannot be left bank. Press OK to try again.",'Virtual Network Validation','OK','Error')
    }
    
    If($ValidationPassed -eq "Yes")
    {
        $VerifyNewVNetButton.Enabled = $False
        $CreateNewVNetButton.Enabled = $true
        $NewVNetNameTextBox.Enabled = $False
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
    }
    Else
    {
        $NewVNetNameTextBox.Enabled = $true
        $CreateNewVNetButton.Enabled = $False
    }

}

Function CreateNewVNet
{
    [String]$VNetNameText = $NewVNetNameTextBox.Text
    $RGLocation = (Get-AzResourceGroup -Name $Global:ResourceGroupName).Location
    New-AzVirtualNetwork -Name $VNetNameText -ResourceGroupName $Global:ResourceGroupName -Location $RGLocation -AddressPrefix $NewVNetDropDown.Text
    If(Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $VNetNameText -ErrorAction SilentlyContinue)
    {
        $CreateVNet = [System.Windows.MessageBox]::Show("The VNet " + $VNetNameText + " has been successfully created.`nIf you are finished creating creating VNets, press Yes to close form and continue or `npress No to create another VNet.",'Virutal Network Creation','YesNo','Question')
    }
    else
    {
        [System.Windows.MessageBox]::Show("The VNet " + $VNetNameText + " failed to create. Press OK to try again.",'Virutal Network Creation','Ok','Error')
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $NewVNetNameTextBox.Enabled = $true
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
    }

    If($CreateVNet -eq "Yes")
    {
        ResourceGroupChange
        $NewVnetCheckBox.Checked = $False
        $NewVNetNameTextBox.Enabled = $true
        $NewVNetNameTextBox.Clear()
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
    }
    Else
    {
        $NewVNetNameTextBox.Enabled = $true
        $NewVNetNameTextBox.Clear()
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
        ResourceGroupChange
        $NewVNetDropDown.Items.Clear()
        CreateVNetObects "Checked"
        $NewVNetDropDown.SelectedItem = 0
    }
}

Function CreateNewSubNetObects($checkstate)
{
    If($checkstate -eq "Checked")
    {
        $AzureVirtualSubnetDropdown.Enabled = $False
        CreateTextBoxLabel $NewSubnetNameLabel (610*$XMultiplier) (160*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Virtual Network Name"
        CreateTextBoxObject $NewSubnetNameTextBox (610*$XMultiplier) (180*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateDropDownMenus $NewSubnetDropDown (610*$XMultiplier) (250*$yMultiplier) (200*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Subnet IP Range -"
        CreateTextBoxLabel $NewSubnetDescriptionLabel (610*$XMultiplier) (220*$yMultiplier) (300*$xMultiplier) (20*$yMultiplier) "Class C Subnets are used for Simplicity"
        CreateButton $VerifyNewSubnetButton (610*$XMultiplier) (290*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Verify New Subnet" "Validate"
        CreateButton $CreateNewSubnetButton (610*$XMultiplier) (340*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Create New Subnet" "Create"
        $NewSubnetNameLabel.Show()
        $NewSubnetNameTextBox.Show()
        $NewSubnetDropDown.Show()
        $NewSubnetDescriptionLabel.Show()
        $VerifyNewSubnetButton.Show()
        $CreateNewSubnetButton.Show()
        $CreateNewSubnetButton.Enabled = $False
        $CreateNewSubnetButton.BackColor = "#aba7a7"
        $NewSubnetDropDown.enabled = $true

        ### Retrieving Subnets to be used for duplicate checking when building the dropdown
        ### We need to create a vnet object so that we can query the subnet address prefixes
        $VNetObj = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $AzureVirtualNetworkDropdown.SelectedItem)
        [string]$VNetPrefix = $VNetObj.AddressSpace.AddressPrefixes    
        $SubnetAddrList = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $VNetObj
        #### Populatng dropdown menu
        $SubNETCreateCheck = 1
        $SubNETFirstOctet = $VNetPrefix.Substring(0,$VNetPrefix.IndexOf("."))  
        $SubNETThirdOctet = 1
        DO
        {
            $SubnetString = [string]$SubNETFirstOctet + '.0.' + $SubNETThirdOctet + '.0/24'
            $Match = $false 
            ForEach($Address in $SubnetAddrList)
            {
                [String]$SubNetFromArray = $Address.AddressPrefix
                If($SubnetString -eq $SubNetFromArray)
                {
                    $Match = $True
                    $SubNETThirdOctet++
                }
            }
            If($Match -eq $false)
            {
                $NewSubnetDropDown.Items.Add($SubnetString)
                $SubNETThirdOctet++
                $SubNETCreateCheck++
            }            
        } Until ($SubNETCreateCheck -gt 10)
        SortDropDownMenu $NewSubnetDropDown
    }
    Else
    {
        $AzureVirtualSubnetDropdown.Enabled = $True
        $NewSubnetDropDown.Items.Clear()
        $NewSubnetNameLabel.Hide()
        $NewSubnetNameTextBox.Hide()
        $NewSubnetDropDown.Hide()
        $NewSubnetDescriptionLabel.Hide()
        $VerifyNewSubnetButton.Hide()
        $CreateNewSubnetButton.Hide()
    } 
}

Function VerifyNewSubnet
{
    ### Resetting Items to enabled state
    $NewSubnetNameTextBox.Enabled = $true
    $CreateNewSubnetButton.Enabled = $False
    $VerifyNewSubnetButton.Enabled = $True

    $ValidationPassed = $False
    If($NewSubnetNameTextBox.Text -NE "")
    {
        $VNetObj = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $AzureVirtualNetworkDropdown.SelectedItem)  
        if(Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $VNetObj -Name $NewSubnetNameTextBox.Text -ErrorAction SilentlyContinue)
        {
            
            [System.Windows.MessageBox]::Show("The Subnet " + $NewSubnetNameTextBox.Text + " already exists. Press OK to try again.",'Subnet Validation','OK','Error')
        }
        else
        {
            ### Checking for special Characters and Spaces
            If(($NewSubnetNameTextBox.Text -match '[^a-zA-Z0-9^-]') -eq $True)
            {
                [System.Windows.MessageBox]::Show("The Subnet Name cannot contain spaces or special characters.`nPress OK to try again.",'Subnet Validation','OK','Error')
            }
            Else
            {
                If($NewSubnetDropDown.SelectedIndex -eq 0)
                {
                    $SubNetSelectionMsgText = "Subnet Address Range is not selected, press OK to continue and select a Subnet Address Range."
                    [System.Windows.MessageBox]::Show($SubNetSelectionMsgText,'Subnet Validation','OK','Error')
                }
                Else
                {
                    $SubNetSelectionMsgText = "Verify that " + $NewSubnetDropDown.Text + " is the correct Address Range."
                    $ValidationPassed = [System.Windows.MessageBox]::Show($SubNetSelectionMsgText + "`nThe Subnet " + $NewSubnetNameTextBox.Text + " has passed Validation. Press Yes to Continue or No to Go Back",'Subnet Validation','YesNo','Question')
                }
            }
        }
    }
    Else
    {
        [System.Windows.MessageBox]::Show("The Subnet Name Field cannot be left bank. Press OK to try again.",'Subnet Validation','OK','Error')
    }
    
    If($ValidationPassed -eq "Yes")
    {
        $VerifyNewSubnetButton.Enabled = $False
        $CreateNewSubnetButton.Enabled = $true
        $NewSubnetNameTextBox.enabled = $False
        $VerifyNewSubnetButton.BackColor = "#aba7a7"
        $CreateNewSubnetButton.BackColor = "#7eb801"
    }
    Else
    {
        $VerifyNewSubnetButton.Enabled = $true
        $CreateNewSubnetButton.Enabled = $False
    }
}
Function CreateNewSubnet
{
    $VNetObj = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $AzureVirtualNetworkDropdown.SelectedItem)  
    Add-AzureRmVirtualNetworkSubnetConfig -Name $NewSubnetNameTextBox.Text -AddressPrefix $NewSubnetDropDown.Text -VirtualNetwork $VNetObj
    Set-AzureRmVirtualNetwork -VirtualNetwork $VNetObj
    $VNetObj = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $AzureVirtualNetworkDropdown.SelectedItem)
    $Global:SubID = (Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $VNetObj -Name $NewSubnetNameTextBox.Text).Id

    If(Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $VNetObj -Name $NewSubnetNameTextBox.Text -ErrorAction Continue)
    {
        $CreateSubNet = [System.Windows.MessageBox]::Show("The Subnet " + $NewSubnetNameTextBox.Text + " has been successfully created.`nIf you are finished creating creating Subnets, press Yes to close the form and continue or `npress No to create another Subnet.",'Subnet Creation','YesNo','Question')
    }
    else
    {
        [System.Windows.MessageBox]::Show("The Subnet " + $NewSubnetNameTextBox.Text + " failed to create. Press OK to try again.",'Subnet Creation','Ok','Error')
        $VerifyNewSubnetButton.BackColor = "#aba7a7"
        $CreateNewSubnetButton.BackColor = "#7eb801"
        $NewSubnetNameTextBox.Enabled = $true
        $CreateNewSubnetButton.Enabled = $False
        $VerifyNewSubnetButton.Enabled = $True
    }

    If($CreateSubNet -eq "Yes")
    {
        NetworkGroupChange
        $NewSubNetCheckBox.Checked = $False
        $NewSubnetNameTextBox.Enabled = $true
        $NewSubnetNameTextBox.Clear()
        $VerifyNewSubnetButton.BackColor = "#aba7a7"
        $CreateNewSubnetButton.BackColor = "#7eb801"
        $CreateNewSubnetButton.Enabled = $False
        $VerifyNewSubnetButton.Enabled = $True
    }
    Else
    {
        $NewSubnetNameTextBox.Enabled = $true
        $NewSubnetNameTextBox.Clear()
        $VerifyNewSubnetButton.BackColor = "#aba7a7"
        $CreateNewSubnetButton.BackColor = "#7eb801"
        $CreateNewSubnetButton.Enabled = $False
        $VerifyNewSubnetButton.Enabled = $True
        NetworkGroupChange
        $NewSubnetDropDown.Items.Clear()
        CreateNewSubNetObects "Checked"
        $NewSubnetDropDown.SelectedItem = 0
    }
}

Function CreateNewDCObects($checkstate)
{
     If($checkstate -eq "Checked")
    {
        ### Creating Textboxes and Labels
        CreateTextBoxLabel $NewDCCompNameLabel (20*$XMultiplier) (240*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "DC Name Prefix"
        CreateTextBoxLabel $NewDCCountLabel (70*$XMultiplier) (310*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Domain Controller Count"
        CreateTextBoxObject $NewDCNameTextBox (20*$XMultiplier) (270*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateTextBoxObject $NewDCCountTextBox (20*$XMultiplier) (310*$yMultiplier) (40*$XMultiplier) (20*$XMultiplier)

        ### Populating Image Dropdown Menu
        CreateDropDownMenus $NewDCImageDropDown(20*$XMultiplier) (350*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Gallery Image -"
        ForEach($Image in $Global:ServerImageArray){$NewDCImageDropDown.Items.Add($Image)}
        SortDropDownMenu $NewDCImageDropDown
        
        ### Populating Machine Type Dropdown
        CreateDropDownMenus $NewDCMachineTypeDropDown(20*$XMultiplier) (390*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Machine Size -"
        $MachineSizeTable= $Global:BClassTable.GetEnumerator()
        ForEach($MachineType in $MachineSizeTable)
        {
            $MachineType.key
            $RAM = ($Global:BClassTable[$MachineType.key].RAM/1024)
            $CPU = $Global:BClassTable[$MachineType.key].CPU
            If($CPU -ge 2 -and $CPU -le 4 -and $RAM -ge 4 -and $RAM -le 16)
            { 
                [String]$DropDownText = $MachineType.key + "(" + $RAM + "GB RAM," + $CPU + " CPUs)"
                $NewDCMachineTypeDropDown.Items.Add($DropDownText)
            }
        }
        SortDropDownMenu $NewDCMachineTypeDropDown
        CreateButton $VerifyNewDCButton (20*$XMultiplier) (430*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Validate DC Config" "Validate"
        CreateButton $CreateNewDCButton (20*$XMultiplier) (490*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) 'Create New DC(s)' "Create"
        $CreateNewDCButton.Enabled = $False
        $CreateNewDCButton.BackColor = "#aba7a7"
    }
    Else
    {
       $NewDCNameTextBox.text = ""
       $NewDCNameTextBox.Hide()
       $NewDCCountTextBox.text = ""
       $NewDCCountTextBox.Hide()
       $NewDCCompNameLabel.Hide()
       $NewDCCountLabel.Hide()
       $NewDCImageDropDown.Hide()
       $NewDCImageDropDown.Items.Clear()
       $NewDCMachineTypeDropDown.Hide()
       $NewDCMachineTypeDropDown.Items.Clear()
       $VerifyNewDCButton.Hide()
       $CreateNewDCButton.hide()
    }
}

Function CreateNewMSObects($Checkstate)
{
    If($checkstate -eq "Checked")
    {        
        ### Creating Textboxes and Labels
        CreateTextBoxObject $NewMSNameTextBox (340*$XMultiplier) (270*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateTextBoxObject $NewMSCountTextBox (340*$XMultiplier) (310*$yMultiplier) (40*$XMultiplier) (20*$XMultiplier)
        CreateTextBoxLabel $NewMSCompNameLabel (340*$XMultiplier) (240*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Member Server Name Prefix"
        CreateTextBoxLabel $NewMSCountLabel (390*$XMultiplier) (310*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Member Server Count"
            
        ### Populating Image Dropdown Menu
        CreateDropDownMenus $NewMSImageDropDown (340*$XMultiplier) (350*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Gallery Image -"
        ForEach($Image in $Global:ServerImageArray){$NewMSImageDropDown.Items.Add($Image)}
        SortDropDownMenu $NewMSImageDropDown
        
        ### Populating Machine Type Dropdown
        CreateDropDownMenus $NewMSMachineTypeDropDown (340*$XMultiplier) (390*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Machine Size  -"
        $MachineSizeTable= $Global:DClassTable.GetEnumerator()
        ForEach($MachineType in $MachineSizeTable)
        {
            $MachineType.key
            $RAM = ($Global:DClassTable[$MachineType.key].RAM/1024)
            $CPU = $Global:DClassTable[$MachineType.key].CPU
            If($CPU -ge 4 -and $CPU -le 8 -and $RAM -ge 8 -and $RAM -le 32 -and $MachineType.key -like "Standard_D*V5")
            { 
                [String]$DropDownText = $MachineType.key + "(" + $RAM + "GB RAM," + $CPU + " CPUs)"
                $NewMSMachineTypeDropDown.Items.Add($DropDownText)
            }
        }
        SortDropDownMenu $NewMSMachineTypeDropDown
        CreateButton $VerifyNewMSButton (340*$XMultiplier) (430*$yMultiplier) (220*$XMultiplier) (40*$xMultiplier) "Validate MemberServer Config" "Validate"
        CreateButton $CreateNewMSButton (340*$XMultiplier) (490*$yMultiplier) (220*$XMultiplier) (40*$xMultiplier) 'Create New MemberServer(s)' "Create"
        $CreateNewMSButton.Enabled = $false
        $CreateNewMSButton.BackColor = "#aba7a7"
    }
    Else
    {
       $NewMSNameTextBox.Text = ""
       $NewMSNameTextBox.Hide()
       $NewMSCountTextBox.Text = ""
       $NewMSCountTextBox.Hide()
       $NewMSCompNameLabel.Hide()
       $NewMSCountLabel.Hide()
       $NewMSImageDropDown.Hide()
       $NewMSImageDropDown.Items.Clear()
       $NewMSMachineTypeDropDown.Hide()
       $NewMSMachineTypeDropDown.Items.Clear()
       $VerifyNewMSButton.hide()
       $CreateNewMSButton.Hide()
    }
}

Function CreateNewWSObects($CheckState)
{
If($checkstate -eq "Checked")
    {
        ### Creating Textboxes and Labels
        CreateTextBoxLabel $NewWSCompNameLabel (610*$XMultiplier) (240*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Workstation Name Prefix"
        CreateTextBoxLabel $NewWSCountLabel (660*$XMultiplier) (310*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Workstation Count"
        CreateTextBoxObject $NewWSNameTextBox (610*$XMultiplier) (270*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateTextBoxObject $NewWSCountTextBox (610*$XMultiplier) (310*$yMultiplier) (40*$XMultiplier) (20*$XMultiplier)

        ### Populating Image Dropdown Menu
        CreateDropDownMenus $NewWSImageDropDown (610*$XMultiplier) (350*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Gallery Image -"
        ForEach($Image in $Global:DesktopImageArray){$NewWSImageDropDown.Items.Add($Image)}
        SortDropDownMenu $NewWSImageDropDown
        
        ### Populating Machine Type Dropdown
        CreateDropDownMenus $NewWSMachineTypeDropDown (610*$XMultiplier) (390*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Machine Size  -"
        $MachineSizeTable= $Global:DClassTable.GetEnumerator()
        ForEach($MachineType in $MachineSizeTable)
        {
            $MachineType.key
            $RAM = ($Global:DClassTable[$MachineType.key].RAM/1024)
            $CPU = $Global:DClassTable[$MachineType.key].CPU
            If($CPU -ge 2 -and $CPU -le 4 -and $RAM -ge 2 -and $RAM -le 16 -and $MachineType.key -like "Standard_D*V2")
            { 
                [String]$DropDownText = $MachineType.key + "(" + $RAM + "GB RAM," + $CPU + " CPUs)"
                $NewWSMachineTypeDropDown.Items.Add($DropDownText)
            }
        }
        SortDropDownMenu $NewWSMachineTypeDropDown
        CreateButton $VerifyNewWSButton (610*$XMultiplier) (430*$yMultiplier) (220*$XMultiplier) (40*$xMultiplier) 'Validate Workstation Config' "Validate"
        CreateButton $CreateNewWSButton (610*$XMultiplier) (490*$yMultiplier) (220*$XMultiplier) (40*$xMultiplier) 'Create New Workstation(s)' "Create"
        $CreateNewWSButton.Enabled = $False
        $CreateNewWSButton.BackColor = "#aba7a7"
    }
    Else
    {
       $NewWSCompNameLabel.Hide()
       $NewWSCountLabel.Hide()
       $NewWSNameTextBox.Hide()
       $NewWSNameTextBox.Text = ""
       $NewWSCountTextBox.Text = ""
       $NewWSCountTextBox.Hide()
       $NewWSImageDropDown.Hide()
       $NewWSImageDropDown.Items.Clear()
       $NewWSMachineTypeDropDown.Hide()
       $NewWSMachineTypeDropDown.Items.Clear()
       $VerifyNewWSButton.Hide()
       $CreateNewWSButton.hide()
    }
}


#### Creating Form Objects
### Creating Dropdown Menus
CreateDropDownMenus $AzureSubscriptionsDropdown (20*$XMultiplier) (20*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Subscription -"
CreateDropDownMenus $AzureResourceGroupDropdown (20*$XMultiplier) (120*$yMultiplier) (300*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Resource Group -"
CreateDropDownMenus $AzureVirtualNetworkDropdown (340*$XMultiplier) (120*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure VNet -"
CreateDropDownMenus $AzureVirtualSubnetDropdown (610*$XMultiplier) (120*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Subnet -"

### Creating Text Labels
CreateTextBoxLabel $NewRGLabel (40*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Resource Group"
CreateTextBoxLabel $NewVNetLabel (360*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Vnet"
CreateTextBoxLabel $NewSubnetLabel (630*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Subnet"
CreateTextBoxLabel $NewDCCBLabel (40*$XMultiplier) (202.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Domain Controller"
CreateTextBoxLabel $NewWSCBLabel (630*$XMultiplier) (202.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Workstation"
CreateTextBoxLabel $NewMSCBLabel (360*$XMultiplier) (202.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Member Server"

### Creating Text Boxes


### Creating Buttons



### Creating CheckBox
CreateCheckBox $NewRGCheckBox (20*$XMultiplier) (80*$yMultiplier)
$NewRGCheckBox.Enabled = $false
$NewRGCheckBox.BringToFront()
CreateCheckBox $NewVnetCheckBox (340*$XMultiplier) (80*$yMultiplier)
$NewVnetCheckBox.Enabled = $false
CreateCheckBox $NewSubNetCheckBox (610*$XMultiplier) (80*$yMultiplier)
$NewSubNetCheckBox.Enabled = $false
CreateCheckBox $NewDCCheckBox (20*$XMultiplier) (200*$yMultiplier)
CreateCheckBox $NewMSCheckBox (340*$XMultiplier) (200*$yMultiplier)
CreateCheckBox $NewWSCheckBox (610*$XMultiplier) (200*$yMultiplier)

### Populating Azure Subscriptions
$AzureSubscriptionsDropdown.Enabled = $true
$AzureSubscriptions = get-azsubscription | select name
ForEach($Subscription in $AzureSubscriptions){$AzureSubscriptionsDropdown.Items.Add($Subscription.Name)}
$AzureSubscriptionsDropdown.Sorted = $true
$AzureSubscriptionsDropdown.SelectedItem = $AzureSubscriptionsDropdown.Items[0]

### Populating AZ Locations Table
GetAZLocations
#CreateNewRGObects

### Dropdown Change Actions
$AzureSubscriptionsDropdown.Add_SelectedValueChanged({SubscriptionDropDownChange})
$AzureResourceGroupDropdown.Add_SelectedValueChanged({ResourceGroupChange})
$AzureVirtualNetworkDropdown.Add_SelectedValueChanged({NetworkGroupChange})

### CheckBox State Change Actions
$NewVnetCheckBox.Add_CheckStateChanged({CreateVNetObects $NewVnetCheckBox.CheckState})
$NewRGCheckBox.Add_CheckStateChanged({CreateNewRGObects $NewRGCheckBox.CheckState})
$NewSubNetCheckBox.Add_CheckStateChanged({CreateNewSubNetObects $NewSubNetCheckBox.CheckState}) 
$NewDCCheckBox.Add_CheckStateChanged({CreateNewDCObects $NewDCCheckBox.CheckState})
$NewMSCheckBox.Add_CheckStateChanged({CreateNewMSObects $NewMSCheckBox.CheckState})
$NewWSCheckBox.Add_CheckStateChanged({CreateNewWSObects $NewWSCheckBox.CheckState})

### Button Click Actions
$VerifyNewRGButton.Add_Click({VerifyRG})
$CreateNewRGButton.Add_Click({CreateNewRG})
$VerifyNewVNetButton.Add_Click({VerifyVNet})
$CreateNewVNetButton.Add_Click({CreateNewVNet})
$VerifyNewSubnetButton.Add_Click({VerifyNewSubnet})
$CreateNewSubnetButton.Add_Click({CreateNewSubnet})

### Presenting Windows Form
$Global:Form.Add_Shown({$Global:Form.Activate()})
[void] $Global:Form.ShowDialog() 