﻿#Get-AzureRmVirtualNetwork -ResourceGroupName RSG-COVID19-Response -Name vnetCOVID19-Response | Get-AzureRmVirtualNetworkSubnetConfig
$AzureVirtualNetworks = Get-AzVirtualNetwork
ForEach($Network in $AzureVirtualNetworks)
{
   $AZResourceGroup = $Network.ResourceGroupName 
   $AZResrouceName = $Network.Name
   #$AZResourceGroup
   $VNetPreFix = $Network.AddressSpace.AddressPrefixes

   $VNET = Get-AzVirtualNetwork -ResourceGroupName $AZResourceGroup -Name $AZResrouceName
   $SubnetList = $Network.Subnets
   ForEach($Prefix in $SubnetList)
   {
       #Write-host $Prefix.Name
       (Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $VNET -Name $prefix.Name).AddressPrefix
       #Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork $VNET -Name $prefix.Name
   }
}