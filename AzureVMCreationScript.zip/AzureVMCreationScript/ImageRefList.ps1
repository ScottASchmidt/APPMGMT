﻿### Create VM Image Library
### Desktop Images
$DesktopImageArray = @()
$ServerImageArray = @()
$Win10Image = Get-AzVMImageSku -Location 'Central US' -PublisherName MicrosoftWindowsDesktop -Offer Windows-10 | Where-Object{$_.Skus -like "*ent-g2"} | select skus
$Win11Image = Get-AzVMImageSku -Location 'Central US' -PublisherName MicrosoftWindowsDesktop -Offer Windows-11 | Where-Object{$_.Skus -like "*ent"} | select skus
### Contains 2012,2012R2,206,2019
$Server201xImage = Get-AzVMImageSku -Location 'Central US' -PublisherName MicrosoftWindowsserver -Offer WindowsServer | Where-Object{$_.Skus -like "*datacenter-gensecond"} | select skus
### Contains Server 2022 and forward images
$Server202xImage = Get-AzVMImageSku -Location 'Central US' -PublisherName MicrosoftWindowsserver -Offer WindowsServer | Where-Object{$_.Skus -like "*datacenter-g2"} | select skus
ForEach($SKU in $Win10Image){$DesktopImageArray += $SKU.Skus}
ForEach($SKU in $Win11Image){$DesktopImageArray += $SKU.Skus}
ForEach($SKU in $Server201xImage){$ServerImageArray += $SKU.Skus}
ForEach($SKU in $Server202xImage){$ServerImageArray += $SKU.Skus}
$DesktopImageArray
$ServerImageArray