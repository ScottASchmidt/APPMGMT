﻿### Setting Launch Params
param(
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$AzureUserName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$TenantName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][ValidateSet("True", "False")][String]$HighRes
)

### Enable-AzureRMAlias allows for Legacy AzureRM Cmdlets to be used
Enable-AzureRMAlias

#$ErrorActionPreference = "SilentlyContinue"
$CurrentDirectory = $PSScriptRoot

### Always Add These to PowerShell Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationFramework

### If HighRes Screen is set the form multiplier will be reset to accomodate a larger size
If($HighRes -eq "True")
{
    $Global:XMultiplier=2
    $Global:yMultiplier=2
}
Else
{
    $Global:XMultiplier=1
    $Global:yMultiplier=1
}

### Setting Up PowerShell Form
$Global:Form = New-Object System.Windows.Forms.Form    
$Global:Form.Size = New-Object System.Drawing.Size((1024*$Global:XMultiplier),(800*$Global:yMultiplier))  
$Global:Form.Text = "Lab Hydration Utility"  
$Global:ClientName = "Microsoft"

### Authenticating to Graph / Tenant
function Get-AuthToken
{
    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )

    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    $tenant = $userUpn.Host

    Write-Host "Checking for AzureAD module..."

    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($AadModule -eq $null)
    {
        Write-Host "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }

    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    $resourceAppIdURI = "https://graph.microsoft.com"
    $authority = "https://login.microsoftonline.com/$Tenant"

    try {
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
        # https://msdn.microsoft.com/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
        # If the accesstoken is valid then create the authentication header
        if ($authResult.AccessToken) {
            # Creating header for Authorization token
            $authHeader = @{
                'Content-Type' = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn' = $authResult.ExpiresOn
            }
            return $authHeader
        }
        else {
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
        }
    }
    catch {
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    }   
}

######### Creating Form Objects #########
### Creating Label Objects
$RDSInfraLabel = New-Object System.Windows.Forms.Label


### Creating Drop Down Menu
$AzureSubscriptionsDropdown = New-Object System.Windows.Forms.ComboBox
$AzureResourceGroupDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualNetworkDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualSubnetDropdown = New-Object System.Windows.Forms.ComboBox

### Creating Text Box Objects
$VDIUserCountTextBox = New-Object System.Windows.Forms.TextBox

### Creating Buttons
$EstimateComputeButton = New-Object System.Windows.Forms.Button 
$ProvisionVMButton = New-Object System.Windows.Forms.Button 



######### Functions for Creating Form Objects #########

### Function to Create DropDown Menus
Function CreateDropDownMenus($DropdownObject,$PosX,$PosY,$BoxLen,$BoxHeight,$MenuHeight,$TextforFirstItem)
{
    $DropdownObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $DropdownObject.Size = new-object System.Drawing.Size($BoxLen,$BoxHeight)
    $DropdownObject.DropDownHeight = 300
    $DropdownObject.Enabled = $False
    $DropdownObject.Items.Add($TextforFirstItem)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
    $DropdownObject.BringToFront()
    $DropdownObject.Font = New-Object System.Drawing.Font("Lucida Console",(9*$XMultiplier),[System.Drawing.FontStyle]::Regular)
    $Form.Controls.Add($DropdownObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Text Labels
Function CreateTextBoxLabel($TextBoxLabel,$PosX,$PosY,$BoxLen,$BoxHeight,$Title)
{
    $TextBoxLabel.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxLabel.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxLabel.Text = $Title
    $TextBoxLabel.BringToFront()
    $Global:form.Controls.Add($TextBoxLabel)
}

### Function to Create Text Box 
Function CreateTextBoxObject($TextBoxObject,$PosX,$PosY,$BoxLen,$BoxHeight)
{
    #Write-host $BoxHeight
    $TextBoxObject.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxObject.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxObject.BringToFront()
    $Global:form.Controls.Add($TextBoxObject)
}

### Function to Create Buttons
Function CreateButton($ButtonObject,$PosX,$PosY,$ButtonLen,$ButtonHeight,$ButtonText)
{  
    $ButtonObject.Location = New-Object System.Drawing.Size($PosX,$PosY) 
    $ButtonObject.AutoSize = $True
    $ButtonObject.Font = $Global:High_DPIScale_Font
    $ButtonObject.Text = $ButtonText
    $ButtonObject.BringToFront()
    $Form.Controls.Add($ButtonObject)
}

### Connecting to Azure
$Global:authToken = Get-AuthToken -User $AzureUserName

### Creating Dropdown Menus
CreateDropDownMenus $AzureSubscriptionsDropdown (20*$XMultiplier) (20*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "Choose Azure Subscription"
CreateDropDownMenus $AzureResourceGroupDropdown (20*$XMultiplier) (80*$yMultiplier) (300*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "Choose Azure Resource Group"
CreateDropDownMenus $AzureVirtualNetworkDropdown (340*$XMultiplier) (80*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "Choose Azure VNet"
CreateDropDownMenus $AzureVirtualSubnetDropdown (610*$XMultiplier) (80*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "Choose Azure Subnet"

####### Populating DropdownMenus #######

### Populating Azure Subscriptions
$AzureSubscriptionsDropdown.Enabled = $true
$AzureSubscriptions = get-azsubscription | select name
ForEach($Subscription in $AzureSubscriptions){$AzureSubscriptionsDropdown.Items.Add($Subscription.Name)}
$AzureSubscriptionsDropdown.Sorted = $true
$AzureSubscriptionsDropdown.SelectedItem = $AzureSubscriptionsDropdown.Items[0]

### Populating Resource Group DropDown -This change is initiated from a change in the subscription dropdown
Function SortDropDownMenu($DropdownObject)
{
    $DropdownObject.Enabled = $true
    $DropdownObject.Sorted = $true
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function ClearDropDownMenu($DropdownObject,$FirstLineText)
{
    $DropdownObject.Items.Clear()
    $DropdownObject.Items.Add($FirstLineText)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function SubscriptionDropDownChange
{
    If($AzureSubscriptionsDropdown.SelectedIndex -gt 0)
    {
        $Global:SubscriptionName = $AzureSubscriptionsDropdown.SelectedItem
        Select-AzSubscription -subscription $Global:SubscriptionName

        ### Populating Azure Resource Groups
        ClearDropDownMenu $AzureResourceGroupDropdown "Choose Azure Resource Group"

        $AzureResourceGroups = Get-AZResourceGroup |select resourcegroupname,location
        ForEach($ResourceGroup in $AzureResourceGroups)
        {
            $ResourceGroupText = $ResourceGroup.ResourceGroupName + " (" + $ResourceGroup.Location + ")"
            $AzureResourceGroupDropdown.Items.Add($ResourceGroupText)
        }
        SortDropDownMenu $AzureResourceGroupDropdown
    }
    Else
    {
        ClearDropDownMenu $AzureResourceGroupDropdown "Choose Azure Resource Group"
    }
}


### Populating VNet Dropdown - Based on Resource Group Selection Changes
Function ResourceGroupChange
{
    If($AzureResourceGroupDropdown.SelectedIndex -gt 0)
    {
        [string]$ResourceGroup = $AzureResourceGroupDropdown.SelectedItem
        $LocationCount = $ResourceGroup.IndexOf(' (' )
        $ResourceLocationLength = $ResourceGroup.Length - ($LocationCount + 11)
        $Global:ResourceGroupName = $ResourceGroup.Substring(0,$LocationCount)

        ### Populating Network Dropdown Info
        ClearDropDownMenu $AzureVirtualNetworkDropdown "Choose Azure Virtual Network"
         
        $AzureVirtualNetworks = Get-AzVirtualNetwork -WarningAction SilentlyContinue -ResourceGroupName $Global:ResourceGroupName
        ForEach($Network in $AzureVirtualNetworks)
        {
           $AzureVirtualNetworkDropdown.Items.Add($Network.Name)
        }
        SortDropDownMenu $AzureVirtualNetworkDropdown

        ### Setting this variable to track location change between functions
        #$Global:LastCheckResouceGroupLocation = $Global:ResourceGroupLocation
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualNetworkDropdown "Choose Azure Virtual Network"
    }
}

### VNet Network
Function NetworkGroupChange
{
    IF($AzureVirtualNetworkDropdown.SelectedIndex -gt 0)
    {
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
        $AzureVirtualNetworks = Get-AzVirtualNetwork
        ForEach($Network in $AzureVirtualNetworks)
        {
            $AZResourceGroup = $Network.ResourceGroupName 
            $AZResrouceName = $Network.Name
            If($AZResrouceName -eq $AzureVirtualNetworkDropdown.SelectedItem)
            {
                $Location = $Network.Location
                $VNetPreFix = $Network.AddressSpace.AddressPrefixes
                #$VNET = Get-AzVirtualNetwork -ResourceGroupName $AZResourceGroup -Name $AZResrouceName
                $SubnetList = $Network.Subnets
                ForEach($Prefix in $SubnetList)
                {
                    $SubnetText = $Prefix.Name + " (" + $Prefix.AddressPrefix + ")"
                    $AzureVirtualSubnetDropdown.Items.Add($SubnetText)
                }
            }
        }
        SortDropDownMenu $AzureVirtualSubnetDropdown
        ### Retrieving VM Types from the Azure Data Center specified in the Network Location
        GetAZMachinesTypes $Location
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
    }
}

Function GetAZMachinesTypes($Location)
{
    $AZMachineArray = Get-AzVmSize -Location $Location
    $Global:DClassTable = @{}
    $Global:BClassTable = @{}
    ForEach($MachineType in $AZMachineArray)
    {
        ### Creating D Class Machine Array
        IF($MachineType.Name -like "Standard_D*V5")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
             $Global:DClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }

        ### Creating B Class Machine Array
        IF($MachineType.Name -like "Standard_B*")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
            $Global:BClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }
    }
    Write-Host $Global:BClassTable["Standard_B2s"].RAM
    #Write-Host $BClassTable.Name
}

### Dropdown Change Actions
$AzureSubscriptionsDropdown.Add_SelectedValueChanged({SubscriptionDropDownChange})
$AzureResourceGroupDropdown.Add_SelectedValueChanged({ResourceGroupChange})
$AzureVirtualNetworkDropdown.Add_SelectedValueChanged({NetworkGroupChange})

### Presenting Windows Form
$Global:Form.Add_Shown({$Global:Form.Activate()})
[void] $Global:Form.ShowDialog() 