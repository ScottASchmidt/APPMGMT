﻿#$ErrorActionPreference = "SilentlyContinue"
$CurrentDirectory = $PSScriptRoot

### Always Add These to PowerShell Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationFramework

### Setting Up PowerShell Form
$Global:XMultiplier=1.5
$Global:yYultiplier=1.5
$Global:Form = New-Object System.Windows.Forms.Form    
$Global:Form.Size = New-Object System.Drawing.Size((800*$Global:XMultiplier),(800*$Global:yYultiplier))  
$Global:Form.Text = "RDS Configuration Utility"  
$Global:ClientName = "FlexManage"
$Global:MachineSizingAlreadyRan = $False

### Connection to Azure Tenant
#Connect-AzureRMAccount

### Creating Checkbox Objects
$UseDefaultSizing = new-object System.Windows.Forms.checkbox

$VMLocalAdminUser='FMLocalAdmin'
$VMLocalAdminSecurePassword = ConvertTo-SecureString 'P@ssw0rd!' -AsPlainText -Force							
$Credential = New-Object System.Management.Automation.PSCredential ($VMLocalAdminUser, $VMLocalAdminSecurePassword);


### Creating Label Objects
$RDSInfraLabel = New-Object System.Windows.Forms.Label
$ClientSizeLabel = New-Object System.Windows.Forms.Label
$AZSubscriptionLabel = New-Object System.Windows.Forms.Label
$AzureInfraLabel = New-Object System.Windows.Forms.Label
$AzureResourceGroupLabel = New-Object System.Windows.Forms.Label
$AzureVirtualNetworksLabel = New-Object System.Windows.Forms.Label
$ResourceGroupLocationLabel = New-Object System.Windows.Forms.Label
$InfrastructureLabel = New-Object System.Windows.Forms.Label
$AZVNet_SubnetLabel = New-Object System.Windows.Forms.Label
$VDIUserCountLabel = New-Object System.Windows.Forms.Label
$NonVDIUserCountLabel = New-Object System.Windows.Forms.Label
$Server1Label = New-Object System.Windows.Forms.Label
$Server2Label = New-Object System.Windows.Forms.Label
$Server3Label = New-Object System.Windows.Forms.Label

### Creating Drop Down Menu
$RDSInfraTypeDropdown = New-Object System.Windows.Forms.ComboBox
$UserCountDropdown = New-Object System.Windows.Forms.ComboBox
$AzureSubscriptionsDropdown = New-Object System.Windows.Forms.ComboBox
$AzureResourceGroupDropdown= New-Object System.Windows.Forms.ComboBox
$AzureVirtualNetworkDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualSubnetDropdown = New-Object System.Windows.Forms.ComboBox

### Setting up VM sizing dropdowns
$SessionHostMachineSizeDropDown = New-Object System.Windows.Forms.ComboBox
$RDS_GW_WWW__CB_LS_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$RDS_GW_WWW_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$RDS_CB_LS_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_SF_DDC_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_VPX_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_FS_SQL_Dropdown = New-Object System.Windows.Forms.ComboBox

### Creating Text Box Objects
$VDIUserCountTextBox = New-Object System.Windows.Forms.TextBox
$NonVDIUserTextBox = New-Object System.Windows.Forms.TextBox
$Server1TextBox = New-Object System.Windows.Forms.TextBox
$Server2TextBox = New-Object System.Windows.Forms.TextBox
$Server3TextBox = New-Object System.Windows.Forms.TextBox
$ComputeTextBoxFrame = New-Object System.Windows.Forms.TextBox

### This line is setting the masking character for the password box
#$Global:Password.PasswordChar='*'
#$Global:USMTPath = New-Object System.Windows.Forms.TextBox
#$Global:USMTPath.Enabled = $False

### Creating Buttons
$EstimateComputeButton = New-Object System.Windows.Forms.Button 
$ProvisionVMButton = New-Object System.Windows.Forms.Button 

#$Global:ResetForm.Add_Click({EnableObjects})
#$Global:Continue = New-Object System.Windows.Forms.Button 
#$Global:Continue.Add_Click({ContinueUSMTProcess})
#$Global:Continue.Enabled = $false

$Global:ExitBUtton = New-Object System.Windows.Forms.Button 
$Global:ExitBUtton.Add_Click({ExitForm})

### Creating Drop Down Menus
Function CreateRDSInfraDropdown
{
        ### Creating RDS Infra Dropdown
        CreateDropDownMenus $RDSInfraTypeDropdown 20 60 200 20 300 "Choose the RDS Backend"
        $RDSInfraTypeDropdown.Enabled = $true
        $RDSInfraTypeDropdown.Items.Add("Citrix")
        $RDSInfraTypeDropdown.Items.Add("Microsoft")
        CreateTextBoxLabel $RDSInfraLabel 20 40 200 15 "RDS Backend Type"
}

Function CreateUserCount
{
    ### Creating User Count DropDown
    CreateDropDownMenus $UserCountDropdown 230 60 200 20 300 "Choose the Client Size"
    $UserCountDropdown.Enabled = $true
    $UserCountDropdown.Items.Add("0 - 50")
    $UserCountDropdown.Items.Add("50 - 100")
    $UserCountDropdown.Items.Add("100 - 250")
    $UserCountDropdown.Items.Add("250 - 1000")
    CreateTextBoxLabel $ClientSizeLabel 230 40 200 15 "Client Size"
}

Function CreateSubscriptionDown
{
    CreateDropDownMenus $AzureSubscriptionsDropdown 20 110 300 20 300 "Choose Azure Subscription"
    $AzureSubscriptionsDropdown.Enabled = $true
    $AzureSubscriptions = get-azsubscription | select name
    ForEach($Subscription in $AzureSubscriptions)
    {
        $AzureSubscriptionsDropdown.Items.Add($Subscription.Name)
    }
    CreateTextBoxLabel $AZSubscriptionLabel 20 90 200 15 "Azure Subscriptions"
}

Function CreateResourceGroupDropDown
{
    CreateDropDownMenus $AzureResourceGroupDropdown 330 110 300 20 300 "Choose Azure Resource Group"
    CreateTextBoxLabel $AzureResourceGroupLabel 330 90 300 15 "Resource Groups"
}

### Create Virtual Network Dropdown
Function CreateVirtualNetworkDropDown
{
    CreateDropDownMenus $AzureVirtualNetworkDropdown 20 170 300 20 300 "Choose Azure Virtual Network"
    CreateTextBoxLabel $AzureVirtualNetworksLabel 20 150 200 15 "Virtual Networks"
}

### Create VirtualSubnet Dropdown
Function CreateVirtualSubnetDropDown
{
    CreateDropDownMenus $AzureVirtualSubnetDropdown 330 170 250 20 300 "Choose VNet Subnet"
    CreateTextBoxLabel $AZVNet_SubnetLabel 330 150 200 15 "VNet Subnets"
}

Function CreateMachineSizingDropdowns
{
    ### Creating Machine Type Dropdown Menus
    ### Creating Dropdown Menus
    CreateDropDownMenus $SessionHostMachineSizeDropDown 215 250 250 20 300 "Choose a VDI Machine Class"
    CreateDropDownMenus $RDS_GW_WWW__CB_LS_SizeDropdown 215 280 250 20 300 "Choose a VDI Machine Class"
    CreateDropDownMenus $RDS_GW_WWW_SizeDropdown 215 280 250 20 300 "Choose a VDI Machine Class"
    CreateDropDownMenus $RDS_CB_LS_SizeDropdown 215 310 250 20 300 "Choose a VDI Machine Class"
    CreateDropDownMenus $CTX_SF_DDC_SizeDropdown 215 280 250 20 300 "Choose a VDI Machine Class"
    CreateDropDownMenus $CTX_FS_SQL_Dropdown 215 310 250 20 300 "Choose a VDI Machine Class"

    ### Hiding Dropdown Menus until they are called
    $Global:Form.Controls.Remove($SessionHostMachineSizeDropDown)
    $Global:Form.Controls.Remove($RDS_GW_WWW__CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_GW_WWW_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_SF_DDC_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_FS_SQL_Dropdown)

    $SessionHostMachineSizeDropDown.Enabled = $true
    $RDS_GW_WWW__CB_LS_SizeDropdown.Enabled = $true
    $RDS_GW_WWW_SizeDropdown.Enabled = $true
    $RDS_CB_LS_SizeDropdown.Enabled = $true
    $CTX_SF_DDC_SizeDropdown.Enabled = $true
    $CTX_FS_SQL_Dropdown.Enabled = $true

    ### Populating Machine Types Dropdown Menu
    $AzMachineTypes = Get-AzureRmVmSize -Location $Global:ResourceGroupLocation

    ### Searching for Index Number to set B4ms server as the default
    ### $Lowcount is at 2 opposed to 0 B4MS does not exist in Low class so it will be placed at 1
    $HighCount = 1
    $LowCount = 2
    $DefaultServerClass = "Standard_B4ms"

    ### Manually adding Default server class to low end machines because it does not qualify as a low end machine
    $RDS_GW_WWW__CB_LS_SizeDropdown.Items.Add($DefaultServerClass + " Resources:4x16")
    $RDS_CB_LS_SizeDropdown.Items.Add($DefaultServerClass + " Resources:4x16")
    $RDS_GW_WWW_SizeDropdown.Items.Add($DefaultServerClass + " Resources:4x16")
    $CTX_SF_DDC_SizeDropdown.Items.Add($DefaultServerClass + " Resources:4x16")

    ForEach($MachineType in $AzMachineTypes)
    {
        If($MachineType.Name.IndexOf("Promo") -eq -1 -and $MachineType.Name.IndexOf("Basic") -eq -1)
        {
            $RAM = ($MachineType.MemoryInMB/1024)
            $CoreCount = $MachineType.NumberOfCores
            ### Session Host Machines
            If($RAM -ge 16 -and $RAM -le 32 -and $CoreCount -eq 4)
            {
                If($MachineType.Name -eq $DefaultServerClass){$Global:DefaultSeverClassIndex = $HighCount}
                $AZHWType = $MachineType.Name + " Resources:" + $CoreCount + "x" + $RAM
                $CTX_FS_SQL_Dropdown.Items.Add($AZHWType)
                $SessionHostMachineSizeDropDown.Items.Add($AZHWType)
                $HighCount++
            }
            elseIf($RAM -ge 4 -and $RAM -le 8 -and $CoreCount -ge 2 -and $CoreCount -le 4)
            {
                $AZHWType = $MachineType.Name + " Resources:" + $CoreCount + "x" + $RAM
                $RDS_GW_WWW__CB_LS_SizeDropdown.Items.Add($AZHWType)
                $RDS_CB_LS_SizeDropdown.Items.Add($AZHWType)
                $RDS_GW_WWW_SizeDropdown.Items.Add($AZHWType)
                $CTX_SF_DDC_SizeDropdown.Items.Add($AZHWType)
                $LowCount++
            }
        }  
    }
    $CTX_FS_SQL_Dropdown.SelectedItem = $CTX_FS_SQL_Dropdown.Items[$Global:DefaultSeverClassIndex]
    $SessionHostMachineSizeDropDown.SelectedItem = $SessionHostMachineSizeDropDown.Items[$Global:DefaultSeverClassIndex]
    $RDS_GW_WWW__CB_LS_SizeDropdown.SelectedItem = $RDS_GW_WWW__CB_LS_SizeDropdown.Items[1]
    $RDS_CB_LS_SizeDropdown.SelectedItem = $RDS_CB_LS_SizeDropdown.Items[1]
    $RDS_GW_WWW_SizeDropdown.SelectedItem = $RDS_GW_WWW_SizeDropdown.Items[1]
    $CTX_SF_DDC_SizeDropdown.SelectedItem = $CTX_SF_DDC_SizeDropdown.Items[1]      
    $Global:MachineSizingAlreadyRan = $true
}


### Function to Create DropDown Menus
Function CreateDropDownMenus($DropdownObject,$PosX,$PosY,$BoxLen,$BoxHeight,$MenuHeight,$TextforFirstItem)
{
    $DropdownObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $DropdownObject.Size = new-object System.Drawing.Size($BoxLen,$BoxHeight)
    $DropdownObject.DropDownHeight = 300
    $DropdownObject.Enabled = $False
    $DropdownObject.Items.Add($TextforFirstItem)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
    $DropdownObject.BringToFront()
    $Form.Controls.Add($DropdownObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Text Labels
Function CreateTextBoxLabel($TextBoxLabel,$PosX,$PosY,$BoxLen,$BoxHeight,$Title)
{
    $TextBoxLabel.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxLabel.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxLabel.Text = $Title
    $TextBoxLabel.BringToFront()
    $Global:form.Controls.Add($TextBoxLabel)
}

### Function to Create Text Box 
Function CreateTextBoxObject($TextBoxObject,$PosX,$PosY,$BoxLen,$BoxHeight)
{
    #Write-host $BoxHeight
    $TextBoxObject.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxObject.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxObject.BringToFront()
    $Global:form.Controls.Add($TextBoxObject)
}

### Function to Create Buttons
Function CreateButton($ButtonObject,$PosX,$PosY,$ButtonLen,$ButtonHeight,$ButtonText)
{  
    $ButtonObject.Location = New-Object System.Drawing.Size($PosX,$PosY) 
    $ButtonObject.AutoSize = $True
    $ButtonObject.Font = $Global:High_DPIScale_Font
    $ButtonObject.Text = $ButtonText
    $ButtonObject.BringToFront()
    $Form.Controls.Add($ButtonObject)
}

### Dropdown Selection Changes
Function ResourceGroupChange
{
    If($AzureResourceGroupDropdown.SelectedIndex -gt 0)
    {
        [string]$ResourceGroup = $AzureResourceGroupDropdown.SelectedItem
        $LocationCount = $ResourceGroup.IndexOf(" Location:")
        $ResourceLocationLength = $ResourceGroup.Length - ($LocationCount + 11)
        $Global:ResourceGroupName = $ResourceGroup.Substring(6,($LocationCount-6))
        $Global:ResourceGroupLocation = $ResourceGroup.Substring($LocationCount + 11,$ResourceLocationLength)
        #If($Global:ResourceGroupLocation -ne $Global:LastCheckResouceGroupLocation)
        #{
            CreateMachineSizingDropdowns
        #}
        ### Populating Network Dropdown Info
        $AzureVirtualNetworkDropdown.Items.Clear()
        $AzureVirtualNetworkDropdown.Items.Add("Choose Azure Virtual Network")
        
        $AzureVirtualNetworks = Get-AzureRmVirtualNetwork -WarningAction SilentlyContinue
        ForEach($Network in $AzureVirtualNetworks)
        {
           $AzureVirtualNetworkDropdown.Items.Add($Network.ResourceGroupName)
        }
        $AzureVirtualNetworkDropdown.SelectedItem = $AzureVirtualNetworkDropdown.Items[0]
        $AzureVirtualNetworkDropdown.Enabled = $true

        ### Setting this variable to track location change between functions
        #$Global:LastCheckResouceGroupLocation = $Global:ResourceGroupLocation
    }
    Else
    {
        $AzureVirtualNetworkDropdown.Items.Clear()
        $AzureVirtualNetworkDropdown.Items.Add("Choose Azure Virtual Network")
        $AzureVirtualNetworkDropdown.SelectedItem = $AzureVirtualNetworkDropdown.Items[0]
        $AzureVirtualNetworkDropdown.Enabled = $False
    }
}

Function UserCountChange
{
    $Global:ClientSize = $UserCountDropdown.SelectedItem
}

Function RDSInfraDropDownChange
{
    If($RDSInfraTypeDropdown.SelectedItem -eq "Microsoft")
    {
        $Global:RemoteAccessProvider = "Microsoft"
    }
    ElseIf($RDSInfraTypeDropdown.SelectedItem -eq "Citrix")
    {
        $Global:RemoteAccessProvider = "Citrix"
    }
}

Function SubscriptionDropDownChange
{
    If($AzureSubscriptionsDropdown.SelectedIndex -gt 0)
    {
        $Global:SubscriptionName = $AzureSubscriptionsDropdown.SelectedItem
        Select-AzSubscription -subscription $Global:SubscriptionName

        ### Populating Azure Resource Groups
        $AzureResourceGroupDropdown.Items.Clear()
        $AzureResourceGroupDropdown.Items.Add("Choose Azure Resource Group")
        $AzureResourceGroups = Get-AZResourceGroup |select resourcegroupname,location
        ForEach($ResourceGroup in $AzureResourceGroups)
        {
            $ResourceGroupText = "Name: " + $ResourceGroup.ResourceGroupName + " Location: " + $ResourceGroup.Location
            $AzureResourceGroupDropdown.Items.Add($ResourceGroupText)
        }
        $AzureResourceGroupDropdown.SelectedItem = $AzureResourceGroupDropdown.Items[0]
        $AzureResourceGroupDropdown.Enabled = $true
    }
    Else
    {
        $AzureResourceGroupDropdown.Items.Clear()
        $AzureResourceGroupDropdown.Items.Add("Choose Azure Resource Group")
        $AzureResourceGroupDropdown.SelectedItem = $AzureResourceGroupDropdown.Items[0]
    }
}

### VNet Network
Function NetworkGroupChange
{
    IF($AzureVirtualNetworkDropdown.SelectedIndex -gt 0)
    {
        ### Setting Resource Group Name from Dropdown so we can make an additional connection to the Network to extract the remaining data
        $Global:VNetResourceGroupName = $AzureVirtualNetworkDropdown.SelectedItem

        ### Making an additional VNet call begin bringing in additional variables
        $VNetLevelNetwork = Get-AzureRmVirtualNetwork -ResourceGroupName $Global:VNetResourceGroupName -WarningAction SilentlyContinue
        $Global:VNetNetworkName = $VNetLevelNetwork.Name
        $Global:VNetNetworkPrefix = $VNetLevelNetwork.AddressSpace.AddressPrefixes

        ### Creating Subnet List Variable
        $VNetSubnets = $VNetLevelNetwork.Subnets

        ### Creating a new VNet Object that is needed for Get-AzureRmVirtualNetworkSubnetConfig CMDlet
        $Global:VNetSUbnetLevelNetwork = Get-AzureRmVirtualNetwork -ResourceGroupName $Global:VNetResourceGroupName -Name $Global:VNetNetworkName -WarningAction SilentlyContinue
        
        ForEach($Net in $VNetSubnets)
        {
            Write-Host $Net.Name
            #$Prefix = (Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork $VNetSUbnetLevelNetwork -Name $Net.Name -WarningAction SilentlyContinue).AddressPrefix
            $AzureVirtualSubnetDropdown.Items.Add($Net.Name)
        }
        $AzureVirtualSubnetDropdown.SelectedItem = $AzureVirtualSubnetDropdown.Items[0]
        $AzureVirtualSubnetDropdown.Enabled = $true
    }
    Else
    {
        $AzureVirtualSubnetDropdown.Items.Clear()
        $AzureVirtualSubnetDropdown.Items.Add("Choose VNet Subnet")
        $AzureVirtualSubnetDropdown.SelectedItem = $AzureVirtualSubnetDropdown.Items[0]
        $AzureVirtualSubnetDropdown.Enabled = $false
    }
}

Function VirtualSubnetChange
{
    If($AzureVirtualSubnetDropdown.SelectedIndex -gt 0)
    {
        $Global:SubnetName = $AzureVirtualSubnetDropdown.SelectedItem
        $Global:SubnetPrefix = (Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork  $Global:VNetSUbnetLevelNetwork -Name $Global:SubnetName -WarningAction SilentlyContinue).AddressPrefix
        $Global:SubnetID = (Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork  $Global:VNetSUbnetLevelNetwork -Name $Global:SubnetName -WarningAction SilentlyContinue).Id
        $EstimateComputeButton.Enabled = $True
    }
    Else
    {
        $Global:SubnetName = $null
        $Global:SubnetPrefix = $null
        $Global:SubnetID = $null
        $EstimateComputeButton.Enabled = $False
    }
}

Function EstimateCompute
{
    ### Clearing Form
    $Global:Form.Controls.Remove($SessionHostMachineSizeDropDown)
    $Global:Form.Controls.Remove($RDS_GW_WWW_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_GW_WWW__CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_SF_DDC_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_FS_SQL_Dropdown)
    $Global:Form.Controls.Remove($Server1TextBox)
    $Global:Form.Controls.Remove($Server1Label)
    $Global:Form.Controls.Remove($Server2TextBox)
    $Global:Form.Controls.Remove($Server2Label)
    $Global:Form.Controls.Remove($Server3TextBox)
    $Global:Form.Controls.Remove($Server3Label)

    ### Calcuating Session Hosts - This Vendor agnostic - Load based on Jump Box and VDI Users
    $JumpBoxusers =  $NonVDIUserTextBox.Text
    $VDIUsers = $VDIUserCountTextBox.Text
    $JumpBoxSessionHosts = [math]::Ceiling($JumpBoxusers / 50)
    $VDISessionHosts = [math]::Ceiling($VDIUsers / 25)
    $TotalSessionHosts = $VDISessionHosts + $JumpBoxSessionHosts


    Write-Host $TotalSessionHosts
    If($Global:RemoteAccessProvider -eq "Microsoft")
    {
        $Global:ResourceNamePrefix = "RDS"
        CreateTextBoxObject $Server1TextBox 30 250 20 15
        CreateTextBoxLabel $Server1Label 55 252.5 150 15 "RDS Session Host Role"

        ### Populating Session Host Text Box
        $Server1TextBox.Text = $TotalSessionHosts
        $Server2TextBox.Text = "1"
        $Server3TextBox.Text = "1"
        If($TotalSessionHosts -gt 8)
        {
            CreateTextBoxObject $Server2TextBox 30 280 20 15
            CreateTextBoxLabel $Server2Label 55 282.5 150 15 "RDS WWW and GW Role"
            CreateTextBoxObject $Server3TextBox 30 310 20 15
            CreateTextBoxLabel $Server3Label 55 312.5 150 15 "RDS SB and LS Role"
            $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
            $Global:Form.Controls.Add($RDS_GW_WWW_SizeDropdown)
            $Global:Form.Controls.Add($RDS_CB_LS_SizeDropdown)
            $ComputeTextBoxFrame.SendToBack()
        }
        ELse
        {
            CreateTextBoxObject $Server2TextBox 30 280 20 15
            CreateTextBoxLabel $Server2Label 55 282.5 150 15 "RDS All Infrastructure Roles"
            $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
            $Global:Form.Controls.Add($RDS_GW_WWW__CB_LS_SizeDropdown)
            $ComputeTextBoxFrame.SendToBack()
        }
    }
    ELseIf($Global:RemoteAccessProvider -eq "Citrix")
    {
        $Global:ResourceNamePrefix = "CTX"
        CreateTextBoxObject $Server1TextBox 30 250 20 15
        CreateTextBoxLabel $Server1Label 55 252.5 150 15 "Citrix Session Host Role"
        CreateTextBoxObject $Server2TextBox 30 280 20 15
        CreateTextBoxLabel $Server2Label 55 282.5 150 15 "Citrix SF and DDC Role"
        CreateTextBoxObject $Server3TextBox 30 310 20 15
        CreateTextBoxLabel $Server3Label 55 312.5 150 15 "Citrix FS and SQL Role"

        ### Populating Session Host Text Box
        $Server1TextBox.Text = $TotalSessionHosts
        $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
        $Global:Form.Controls.Add($CTX_SF_DDC_SizeDropdown)
        $Global:Form.Controls.Add($CTX_FS_SQL_Dropdown)
        $ComputeTextBoxFrame.SendToBack()
        If($TotalSessionHosts -lt 10)
        {
            $Server2TextBox.Text = "1"
            $Server3TextBox.Text = "1"
        }
        Else
        {
            $Server2TextBox.Text = "2"
            $Server3TextBox.Text = "1"
        }
    }
}

Function CreateVirtualNIC
{
    ### Creating Session Host NICs
    If($Global:SessionHostsTotal -gt 0)
    {
        $NICCount=0
        Do
        {
            $NicCount++
            $SHName = $Global:ResourceNamePrefix + "SH" + ('{0:d2}' -f $NICCount)
            $SHNICName = "vNIC-" + $Global:ResourceNamePrefix + "SH" + ('{0:d2}' -f $NICCount)
            $SHNIC = New-AzureRMNetworkInterface -name $SHNICName -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
            Write-Host "Completed NIC Creation of " $SHNICName
            CreateVirtualMachines $SHNIC.Id $SHName $Global:SessionHostsType $Global:ResourceGroupName $Global:ResourceGroupLocation 
            Write-Host "Completed VM Creation of " $SHName

        }Until($NicCount -eq $Global:SessionHostsTotal)
    }
    If($Global:ResourceNamePrefix -eq "CTX")
    {
        If($Global:CTX_SF_DDCTotal -gt 0)
        {
            $NICCount=0
            Do
            {
                $NICCount++
                $SFDDCName = $Global:ResourceNamePrefix + "SFDDC" + ('{0:d2}' -f $NICCount)
                $SFDDCNICName = "vNIC-" + $Global:ResourceNamePrefix + "SFDDC" + ('{0:d2}' -f $NICCount)
                $SFDDCNIC = New-AzureRMNetworkInterface -name $SFDDCNICName -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
                Write-Host "Completed NIC Creation of " $SFDDCNICName
                CreateVirtualMachines $SFDDCNIC.Id $SFDDCName $Global:CTX_SH_DDCType $Global:ResourceGroupName $Global:ResourceGroupLocation 
                Write-Host "Completed VM Creation of " $SFDDCName
            }Until($NICCount -eq $Global:CTX_SF_DDCTotal)
        }
        If($Global:CTX_FS_SQLTotal -gt 0)
        {
            $NICCount=0
            Do
            {
                $NICCount++
                $FSSQLName = $Global:ResourceNamePrefix + "FSSQL" + ('{0:d2}' -f $NICCount)
                $FSSQLNICName = "vNIC-" + $Global:ResourceNamePrefix + "FSSQL" + ('{0:d2}' -f $NICCount)
                $FSSQLNIC = New-AzureRMNetworkInterface -name $FSSQLNICName  -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
                Write-Host "Completed NIC Creation of " $FSSQLNICName
                CreateVirtualMachines $FSSQLNIC.Id $FSSQLName $Global:CTX_FS_SQLType $Global:ResourceGroupName $Global:ResourceGroupLocation 
                Write-Host "Completed VM Creation of " $SFDDCName
            }Until($NICCount -eq $Global:CTX_FS_SQLTotal)
        }
    }
    ElseIF($Global:ResourceNamePrefix -eq "RDS")
    {
        If($Global:SessionHostsTotal -gt 8)
        {                
            If($Global:RDS_CB_LSTotal -gt 0)
            {
                $NICCount=0
                Do
                {
                    $NICCount++
                    $CBLSName = $Global:ResourceNamePrefix + "CBLS" + ('{0:d2}' -f $NICCount) ### Converting end number to 2 digits
                    $CBLSNICName = "vNIC-" + $Global:ResourceNamePrefix + "CBLS" + ('{0:d2}' -f $NICCount) ### Converting end number to 2 digits
                    $CBLSNIC = New-AzureRMNetworkInterface -name $CBLSNICName -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
                    Write-Host "Completed NIC Creation of " $CBLSNICName
                    CreateVirtualMachines $CBLSNIC.Id $CBLSName $Global:RDS_CB_LSType $Global:ResourceGroupName $Global:ResourceGroupLocation 
                    Write-Host "Completed Machine Creation of " $CBLSName
                }Until($NICCount -eq $Global:RDS_CB_LSTotal )
            }

            If($Global:RDS_GW_WWWTotal -gt 0)
            {
                $NICCount=0
                Do
                {
                    $NICCount++
                    $GWWWWName = $Global:ResourceNamePrefix + "GWWWW" + ('{0:d2}' -f $NICCount)
                    $GWWWWNICName = "vNIC-" + $Global:ResourceNamePrefix + "GWWWW" + ('{0:d2}' -f $NICCount)
                    $GWWWWNIC = New-AzureRMNetworkInterface -name $GWWWWNICName -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
                    Write-Host "Completed NIC Creation of " $GWWWWNICName
                    CreateVirtualMachines $GWWWWNIC.Id $GWWWWName $Global:RDS_GW_WWWType $Global:ResourceGroupName $Global:ResourceGroupLocation 
                    Write-Host "Completed Machine Creation of " $GWWWWName
                }Until($NICCount -eq $Global:RDS_GW_WWWTotal)
            }
        }
        Else
        {
            If($Global:RDS_AllRolesTotal -gt 0)
            {
                $NICCount=0
                Do
                {
                    $NICCount++
                    $ALLRolesName = $Global:ResourceNamePrefix + "ALLROLES" + ('{0:d2}' -f $NICCount)
                    $ALLRolesNICName = "vNIC-" + $Global:ResourceNamePrefix + "ALLROLES" + ('{0:d2}' -f $NICCount)
                    $ALLROLESNIC = New-AzureRMNetworkInterface -name $ALLRolesNICName -ResourceGroupName $Global:ResourceGroupName -Location $Global:ResourceGroupLocation -SubnetId $Global:SubnetID
                    Write-Host "Completed NIC Creation of " $ALLRolesNICName
                    CreateVirtualMachines $ALLROLESNIC.Id $ALLRolesName $Global:RDS_AllRolesType $Global:ResourceGroupName $Global:ResourceGroupLocation 
                    Write-Host "Completed Machine Creation of " $ALLRolesName
                }Until($NICCount -eq $Global:RDS_AllRolesTotal)
            }
        }
    }

}

Function CreateVirtualMachines($NICID,$VMName,$MachineType,$ResourceGrpName,$ResourceGrpLocation)
{
   ### Setting Azure VM Variables
   $VirtualMachine = New-AzureRmVMConfig -VMName $VMName -VMSize $MachineType
   $VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential -ProvisionVMAgent -EnableAutoUpdate
   $VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $NICID
   $VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName 'MicrosoftWindowsServer' -Offer 'WindowsServer' -Skus '2019-Datacenter' -Version latest

   ### Creating Azure VM Variables
   New-AzureRmVM -ResourceGroupName $ResourceGrpName -Location $ResourceGrpLocation -VM $VirtualMachine -Verbose
 Pause    
 }

Function ProvisionVMs
{
    Write-Host "AT Provision VMs"
    ### Setting Count and type Variables for Machine provisioning
    If($Global:ResourceNamePrefix -eq "CTX")
    {
        $Global:SessionHostsTotal = $Server1TextBox.Text
        $Global:SessionHostsType = $SessionHostMachineSizeDropDown.SelectedItem
        $Global:SessionHostsType = $Global:SessionHostsType.Substring(0,$Global:SessionHostsType.IndexOf(" Resources:"))

        $Global:CTX_SF_DDCTotal = $Server2TextBox.Text
        $Global:CTX_SH_DDCType = $CTX_SF_DDC_SizeDropdown.SelectedItem
        $Global:CTX_SH_DDCType = $Global:CTX_SH_DDCType.Substring(0,$Global:CTX_SH_DDCType.IndexOf(" Resources:"))

        $Global:CTX_FS_SQLTotal = $Server3TextBox.Text
        $Global:CTX_FS_SQLType = $CTX_FS_SQL_Dropdown.SelectedItem
        $Global:CTX_FS_SQLType = $Global:CTX_FS_SQLType.Substring(0,$Global:CTX_FS_SQLType.IndexOf(" Resources:"))
    }
    ElseIf($Global:ResourceNamePrefix -eq "RDS")
    {
        $Global:SessionHostsTotal = $Server1TextBox.Text
        $Global:SessionHostsType = $SessionHostMachineSizeDropDown.SelectedItem
        $Global:SessionHostsType = $Global:SessionHostsType.Substring(0,$Global:SessionHostsType.IndexOf(" Resources:"))

        If($Global:SessionHostsTotal -gt 8)
        {
            $Global:RDS_GW_WWWTotal = $Server2TextBox.Text
            $Global:RDS_GW_WWWType = $RDS_GW_WWW_SizeDropdown.SelectedItem
            $Global:RDS_GW_WWWType = $Global:RDS_GW_WWWType.Substring(0, $Global:RDS_GW_WWWType.IndexOf(" Resources:"))

            $Global:RDS_CB_LSTotal = $Server2TextBox.Text
            $Global:RDS_CB_LSType = $RDS_CB_LS_SizeDropdown.SelectedItem
            $Global:RDS_CB_LSType = $Global:RDS_CB_LSType.Substring(0,$Global:RDS_CB_LSType.IndexOf(" Resources:"))   
        }
        else
        {
            $Global:RDS_AllRolesTotal = $Server2TextBox.Text
            $Global:RDS_AllRolesType = $RDS_GW_WWW__CB_LS_SizeDropdown.SelectedItem
            $Global:RDS_AllRolesType = $Global:RDS_AllRolesType.Substring(0,$Global:RDS_AllRolesType.IndexOf(" Resources:"))
        }
    }

    ### Running Machine provisioning functions
    CreateVirtualNIC
   # CreateVirtualMachines
}

### Creating Form Objects in Order
CreateTextBoxLabel $InfrastructureLabel 20 20 200 15 "Remote Access Infrastructure"
#CreateTextBoxLabel $AzureInfraLabel 20 375 200 15 "Azure VDI Components"

### Creating Text Box Frame for Compute Calculation
CreateTextBoxObject $ComputeTextBoxFrame 20 230 725 120
$ComputeTextBoxFrame.Multiline = $true
$ComputeTextBoxFrame.ReadOnly = $true
$ComputeTextBoxFrame.SendToBack()

### Create Dropdown Menus
CreateRDSInfraDropdown
#CreateUserCount
CreateSubscriptionDown
CreateResourceGroupDropDown
CreateVirtualNetworkDropDown
CreateVirtualSubnetDropDown

### Create CheckBoxes and Associated Labels
#CreateCheckBox $CaptureCheckbox 20 17.5
#CreateTextBoxLabel $CaptureLabel 40 22 110 15 "Capture User State Data"

#CreateCheckBox $RestoreCheckbox 180 17.5
#CreateTextBoxLabel $RestoreLabel 200 22 110 15 "Restore User State Data"

#CreateCheckBox $USBStorageCheckbox 20 47.5
#CreateTextBoxLabel $USBStorageLabel 40 47.5 110 15 "Use USB Storage"


### Create Textboxes and Associated Labels
CreateTextBoxObject $VDIUserCountTextBox 240 60 100 15
CreateTextBoxLabel $VDIUserCountLabel 240 40 90 15 "VDI User Count"

CreateTextBoxObject $NonVDIUserTextBox 360 60 100 15
CreateTextBoxLabel $NonVDIUserCountLabel 360 40 120 15 "Jump Box User Count"

### Create Buttons
CreateButton $EstimateComputeButton 20 200 100 20 "Calculate Compute Needs"
$EstimateComputeButton.Enabled = $False

CreateButton $ProvisionVMButton 20 360 100 20 "Provision VMs"

#CreateButton $Global:ResetForm 130 185 100 20 "Reset Form"
#CreateButton $Global:Continue 240 185 100 20 "Continue"
#CreateButton $Global:ExitBUtton 350 185 100 20 "Exit"

### Checkbox Behaviors
#$CaptureCheckbox.Add_CheckStateChanged({CaptureCheckBoxActions})
#$RestoreCheckbox.Add_CheckStateChanged({RestoreCheckBoxActions})
#$USBStorageCheckbox.Add_CheckStateChanged({USBCheckBoxActions})


### DropDown Menu Change Actions
$RDSInfraTypeDropdown.Add_SelectedValueChanged({RDSInfraDropDownChange})
$AzureSubscriptionsDropdown.Add_SelectedValueChanged({SubscriptionDropDownChange})
$AzureResourceGroupDropdown.Add_SelectedValueChanged({ResourceGroupChange})
$AzureVirtualNetworkDropdown.Add_SelectedValueChanged({NetworkGroupChange})
$AzureVirtualSubnetDropdown.Add_SelectedValueChanged({VirtualSubnetChange})
$UserCountDropdown.Add_SelectedValueChanged({UserCountChange})


### Button Actions
$EstimateComputeButton.Add_Click({EstimateCompute})
$ProvisionVMButton.Add_Click({ProvisionVMs})

$Global:Form.Add_Shown({$Global:Form.Activate()})
[void] $Global:Form.ShowDialog()
