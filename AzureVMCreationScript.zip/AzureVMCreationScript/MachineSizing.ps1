﻿#High Standard_B4ms 16 4
$AzMachineTypes = Get-AzureRmVmSize -Location $Global:ResourceGroupLocation
$HighCount = 0
$LowCount = 1
ForEach($MachineType in $AzMachineTypes)
{
    If($MachineType.Name.IndexOf("Promo") -eq -1 -and $MachineType.Name.IndexOf("Basic") -eq -1)
    {
        $RAM = ($MachineType.MemoryInMB/1024)
        $CoreCount = $MachineType.NumberOfCores
        ### Session Host Machines
        If($RAM -ge 16 -and $RAM -le 32 -and $CoreCount -eq 4)
        {
            If($MachineType.Name -eq "Standard_B4ms"){Write-Host "B4MS Found" $HighCount}
            Write-Host "High" $MachineType.Name $CoreCount $RAM
            $HighCount++
        }### All other machine types
        elseIf($RAM -ge 4 -and $RAM -le 8 -and $CoreCount -ge 2 -and $CoreCount -le 4)
        {
            Write-Host "Low" $MachineType.Name $CoreCount $RAM
            $LowCount++
        }
    }
}