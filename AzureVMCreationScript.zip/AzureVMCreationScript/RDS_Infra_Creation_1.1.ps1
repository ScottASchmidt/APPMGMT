﻿#$ErrorActionPreference = "SilentlyContinue"
$CurrentDirectory = $PSScriptRoot

### Always Add These to PowerShell Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationFramework

### Setting Up PowerShell Form
$Global:Form = New-Object System.Windows.Forms.Form    
$Global:Form.Size = New-Object System.Drawing.Size(800,800)  
$Global:Form.Text = "RDS Configuration Utility"  
$Global:ClientName = "FlexManage"

### Connection to Azure Tenant
#Connect-AzureRMAccount

### Creating Checkbox Objects
$UseDefaultSizing = new-object System.Windows.Forms.checkbox

### Creating Label Objects
$RDSInfraLabel = New-Object System.Windows.Forms.Label
$ClientSizeLabel = New-Object System.Windows.Forms.Label
$AZSubscriptionLabel = New-Object System.Windows.Forms.Label
$AzureInfraLabel = New-Object System.Windows.Forms.Label
$AzureResourceGroupLabel = New-Object System.Windows.Forms.Label
$AzureVirtualNetworksLabel = New-Object System.Windows.Forms.Label
$ResourceGroupLocationLabel = New-Object System.Windows.Forms.Label
$InfrastructureLabel = New-Object System.Windows.Forms.Label
$AZVNet_SubnetLabel = New-Object System.Windows.Forms.Label
$VDIUserCountLabel = New-Object System.Windows.Forms.Label
$NonVDIUserCountLabel = New-Object System.Windows.Forms.Label
$Server1Label = New-Object System.Windows.Forms.Label
$Server2Label = New-Object System.Windows.Forms.Label
$Server3Label = New-Object System.Windows.Forms.Label

### Creating Drop Down Menu
$RDSInfraTypeDropdown = New-Object System.Windows.Forms.ComboBox
$UserCountDropdown = New-Object System.Windows.Forms.ComboBox
$AzureSubscriptionsDropdown = New-Object System.Windows.Forms.ComboBox
$AzureResourceGroupDropdown= New-Object System.Windows.Forms.ComboBox
$AzureVirtualNetworkDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualSubnetDropdown = New-Object System.Windows.Forms.ComboBox

### Setting up VM sizing dropdowns
$SessionHostMachineSizeDropDown = New-Object System.Windows.Forms.ComboBox
$RDS_GW_WWW__CB_LS_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$RDS_GW_WWW_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$RDS_CB_LS_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_SF_DDC_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_VPX_SizeDropdown = New-Object System.Windows.Forms.ComboBox
$CTX_FS_SQL_Dropdown = New-Object System.Windows.Forms.ComboBox

### Creating Text Box Objects
$VDIUserCountTextBox = New-Object System.Windows.Forms.TextBox
$NonVDIUserTextBox = New-Object System.Windows.Forms.TextBox
$Server1TextBox = New-Object System.Windows.Forms.TextBox
$Server2TextBox = New-Object System.Windows.Forms.TextBox
$Server3TextBox = New-Object System.Windows.Forms.TextBox
$ComputeTextBoxFrame = New-Object System.Windows.Forms.TextBox

#$Global:UserName.Enabled = $False
#$Global:Password = New-Object System.Windows.Forms.MaskedTextBox
#$Global:Password.Enabled = $False
### This line is setting the masking character for the password box
#$Global:Password.PasswordChar='*'
#$Global:USMTPath = New-Object System.Windows.Forms.TextBox
#$Global:USMTPath.Enabled = $False

### Creating Buttons
$EstimateComputeButton = New-Object System.Windows.Forms.Button 

$Global:ResetForm = New-Object System.Windows.Forms.Button 
$Global:ResetForm.Add_Click({EnableObjects})
$Global:Continue = New-Object System.Windows.Forms.Button 
$Global:Continue.Add_Click({ContinueUSMTProcess})
$Global:Continue.Enabled = $false

$Global:ExitBUtton = New-Object System.Windows.Forms.Button 
$Global:ExitBUtton.Add_Click({ExitForm})

### Creating Drop Down Menus
Function CreateRDSInfraDropdown
{
        ### Creating RDS Infra Dropdown
        CreateDropDownMenus $RDSInfraTypeDropdown 20 60 200 20 300 "Choose the RDS Backend"
        $RDSInfraTypeDropdown.Enabled = $true
        $RDSInfraTypeDropdown.Items.Add("Citrix")
        $RDSInfraTypeDropdown.Items.Add("Microsoft")
        CreateTextBoxLabel $RDSInfraLabel 20 40 200 15 "RDS Backend Type"
}

Function CreateUserCount
{
    ### Creating User Count DropDown
    CreateDropDownMenus $UserCountDropdown 230 60 200 20 300 "Choose the Client Size"
    $UserCountDropdown.Enabled = $true
    $UserCountDropdown.Items.Add("0 - 50")
    $UserCountDropdown.Items.Add("50 - 100")
    $UserCountDropdown.Items.Add("100 - 250")
    $UserCountDropdown.Items.Add("250 - 1000")
    CreateTextBoxLabel $ClientSizeLabel 230 40 200 15 "Client Size"
}

Function CreateSubscriptionDown
{
    CreateDropDownMenus $AzureSubscriptionsDropdown 440 60 300 20 300 "Choose Azure Subscription"
    $AzureSubscriptionsDropdown.Enabled = $true
    $AzureSubscriptions = Get-AzureRMSubscription | select name
    ForEach($Subscription in $AzureSubscriptions)
    {
        $AzureSubscriptionsDropdown.Items.Add($Subscription.Name)
    }
    CreateTextBoxLabel $AZSubscriptionLabel 440 40 200 15 "Azure Subscriptions"
}

Function CreateResourceGroupDropDown
{
    CreateDropDownMenus $AzureResourceGroupDropdown 20 410 250 20 300 "Choose Azure Resource Group"
    CreateTextBoxLabel $AzureResourceGroupLabel 20 390 200 15 "Resource Groups"
}

### Create Virtual Network Dropdown
Function CreateVirtualNetworkDropDown
{
    CreateDropDownMenus $AzureVirtualNetworkDropdown 20 470 250 20 300 "Choose Azure Virtual Network"
    CreateTextBoxLabel $AzureVirtualNetworksLabel 20 450 200 15 "Virtual Networks"
}

### Create VirtualSubnet Dropdown
Function CreateVirtualSubnetDropDown
{
    CreateDropDownMenus $AzureVirtualSubnetDropdown 280 470 250 20 300 "Choose VNet Subnet"
    CreateTextBoxLabel $AZVNet_SubnetLabel 280 450 200 15 "VNet Subnets"
}

Function CreateMachineSizingDropdowns
{
### Creating Machine Type Dropdown Menus
### Creating Dropdown Menus
CreateDropDownMenus $SessionHostMachineSizeDropDown 215 145 250 20 300 "Choose a VDI Machine Class"
CreateDropDownMenus $RDS_GW_WWW__CB_LS_SizeDropdown 215 175 250 20 300 "Choose a VDI Machine Class"
CreateDropDownMenus $RDS_GW_WWW_SizeDropdown 215 175 250 20 300 "Choose a VDI Machine Class"
CreateDropDownMenus $RDS_CB_LS_SizeDropdown 215 205 250 20 300 "Choose a VDI Machine Class"
CreateDropDownMenus $CTX_SF_DDC_SizeDropdown 215 175 250 20 300 "Choose a VDI Machine Class"
CreateDropDownMenus $CTX_FS_SQL_Dropdown 215 205 250 20 300 "Choose a VDI Machine Class"

### Hiding Dropdown Menus until they are called
$Global:Form.Controls.Remove($SessionHostMachineSizeDropDown)
$Global:Form.Controls.Remove($RDS_GW_WWW__CB_LS_SizeDropdown)
$Global:Form.Controls.Remove($RDS_GW_WWW_SizeDropdown)
$Global:Form.Controls.Remove($RDS_CB_LS_SizeDropdown)
$Global:Form.Controls.Remove($CTX_SF_DDC_SizeDropdown)
$Global:Form.Controls.Remove($CTX_FS_SQL_Dropdown)

#$AzMachineTypes = Get-AzureRmVmSize -Location $Global:ResourceGroupLocation
#ForEach($MachineType in $AzMachineTypes)
#{
#    If($MachineType.Name.IndexOf("Promo") -eq -1 -and $MachineType.Name.IndexOf("Basic") -eq -1)
#    {
#        $RAM = ($MachineType.MemoryInMB/1024)
#        $CoreCount = $MachineType.NumberOfCores
        ### Session Host Machines
#        If($RAM -ge 16 -and $RAM -le 32 -and $CoreCount -eq 4)
#       {
#            Write-Host "High" $MachineType.Name $RAM $CoreCount
#        }### All other machine types
#        elseIf($RAM -ge 4 -and $RAM -le 8 -and $CoreCount -ge 2 -and $CoreCount -le 4)
#        {
#            Write-Host "Low" $MachineType.Name $RAM $CoreCount
#        }
 #   }
#}
}
### Function to Create DropDown Menus
Function CreateDropDownMenus($DropdownObject,$PosX,$PosY,$BoxLen,$BoxHeight,$MenuHeight,$TextforFirstItem)
{
    $DropdownObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $DropdownObject.Size = new-object System.Drawing.Size($BoxLen,$BoxHeight)
    $DropdownObject.DropDownHeight = 300
    $DropdownObject.Enabled = $False
    $DropdownObject.Items.Add($TextforFirstItem)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
    $DropdownObject.BringToFront()
    $Form.Controls.Add($DropdownObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Text Labels
Function CreateTextBoxLabel($TextBoxLabel,$PosX,$PosY,$BoxLen,$BoxHeight,$Title)
{
    $TextBoxLabel.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxLabel.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxLabel.Text = $Title
    $TextBoxLabel.BringToFront()
    $Global:form.Controls.Add($TextBoxLabel)
}

### Function to Create Text Box 
Function CreateTextBoxObject($TextBoxObject,$PosX,$PosY,$BoxLen,$BoxHeight)
{
    #Write-host $BoxHeight
    $TextBoxObject.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxObject.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxObject.BringToFront()
    $Global:form.Controls.Add($TextBoxObject)
}

### Function to Create Buttons
Function CreateButton($ButtonObject,$PosX,$PosY,$ButtonLen,$ButtonHeight,$ButtonText)
{  
    $ButtonObject.Location = New-Object System.Drawing.Size($PosX,$PosY) 
    $ButtonObject.AutoSize = $True
    $ButtonObject.Font = $Global:High_DPIScale_Font
    $ButtonObject.Text = $ButtonText
    $ButtonObject.BringToFront()
    $Form.Controls.Add($ButtonObject)
}

### Dropdown Selection Changes
Function ResourceGroupChange
{
    If($AzureResourceGroupDropdown.SelectedIndex -gt 0)
    {
        [string]$ResourceGroup = $AzureResourceGroupDropdown.SelectedItem
        $LocationCount = $ResourceGroup.IndexOf(" Location:")
        $ResourceLocationLength = $ResourceGroup.Length - ($LocationCount + 11)
        $Global:ResourceGroupName = $ResourceGroup.Substring(6,($LocationCount-6))
        $Global:ResourceGroupLocation  = $ResourceGroup.Substring($LocationCount + 11,$ResourceLocationLength)

        ### Populating Network Dropdown Info
        $AzureVirtualNetworkDropdown.Items.Clear()
        $AzureVirtualNetworkDropdown.Items.Add("Choose Azure Virtual Network")
        
        $AzureVirtualNetworks = Get-AzureRmVirtualNetwork -WarningAction SilentlyContinue
        ForEach($Network in $AzureVirtualNetworks)
        {
           $AzureVirtualNetworkDropdown.Items.Add($Network.ResourceGroupName)
        }
        $AzureVirtualNetworkDropdown.SelectedItem = $AzureVirtualNetworkDropdown.Items[0]
        $AzureVirtualNetworkDropdown.Enabled = $true
    }
    Else
    {
        $AzureVirtualNetworkDropdown.Items.Clear()
        $AzureVirtualNetworkDropdown.Items.Add("Choose Azure Virtual Network")
        $AzureVirtualNetworkDropdown.SelectedItem = $AzureVirtualNetworkDropdown.Items[0]
        $AzureVirtualNetworkDropdown.Enabled = $False
    }
}

Function UserCountChange
{
    $Global:ClientSize = $UserCountDropdown.SelectedItem
}

Function RDSInfraDropDownChange
{
    If($RDSInfraTypeDropdown.SelectedItem -eq "Microsoft")
    {
        $Global:RemoteAccessProvider = "Microsoft"
    }
    ElseIf($RDSInfraTypeDropdown.SelectedItem -eq "Citrix")
    {
        $Global:RemoteAccessProvider = "Citrix"
    }
}

Function SubscriptionDropDownChange
{
    If($AzureSubscriptionsDropdown.SelectedIndex -gt 0)
    {
        $Global:SubscriptionName = $AzureSubscriptionsDropdown.SelectedItem
        Select-AzureRmSubscription -subscription $Global:SubscriptionName

        ### Populating Azure Resource Groups
        $AzureResourceGroupDropdown.Items.Clear()
        $AzureResourceGroupDropdown.Items.Add("Choose Azure Resource Group")
        $AzureResourceGroups = Get-AzureRmResourceGroup |select resourcegroupname,location
        ForEach($ResourceGroup in $AzureResourceGroups)
        {
            $ResourceGroupText = "Name: " + $ResourceGroup.ResourceGroupName + " Location: " + $ResourceGroup.Location
            $AzureResourceGroupDropdown.Items.Add($ResourceGroupText)
        }
        $AzureResourceGroupDropdown.SelectedItem = $AzureResourceGroupDropdown.Items[0]
        $AzureResourceGroupDropdown.Enabled = $true
    }
    Else
    {
        $AzureResourceGroupDropdown.Items.Clear()
        $AzureResourceGroupDropdown.Items.Add("Choose Azure Resource Group")
        $AzureResourceGroupDropdown.SelectedItem = $AzureResourceGroupDropdown.Items[0]
    }
}

### VNet Network
Function NetworkGroupChange
{
    IF($AzureVirtualNetworkDropdown.SelectedIndex -gt 0)
    {
        ### Setting Resource Group Name from Dropdown so we can make an additional connection to the Network to extract the remaining data
        $Global:VNetResourceGroupName = $AzureVirtualNetworkDropdown.SelectedItem

        ### Making an additional VNet call begin bringing in additional variables
        $VNetLevelNetwork = Get-AzureRmVirtualNetwork -ResourceGroupName $Global:VNetResourceGroupName -WarningAction SilentlyContinue
        $Global:VNetNetworkName = $VNetLevelNetwork.Name
        $Global:VNetNetworkPrefix = $VNetLevelNetwork.AddressSpace.AddressPrefixes

        ### Creating Subnet List Variable
        $VNetSubnets = $VNetLevelNetwork.Subnets

        ### Creating a new VNet Object that is needed for Get-AzureRmVirtualNetworkSubnetConfig CMDlet
        $Global:VNetSUbnetLevelNetwork = Get-AzureRmVirtualNetwork -ResourceGroupName $Global:VNetResourceGroupName -Name $Global:VNetNetworkName -WarningAction SilentlyContinue
        
        ForEach($Net in $VNetSubnets)
        {
            Write-Host $Net.Name
            #$Prefix = (Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork $VNetSUbnetLevelNetwork -Name $Net.Name -WarningAction SilentlyContinue).AddressPrefix
            $AzureVirtualSubnetDropdown.Items.Add($Net.Name)
        }
        $AzureVirtualSubnetDropdown.SelectedItem = $AzureVirtualSubnetDropdown.Items[0]
        $AzureVirtualSubnetDropdown.Enabled = $true
    }
    Else
    {
        $AzureVirtualSubnetDropdown.Items.Clear()
        $AzureVirtualSubnetDropdown.Items.Add("Choose VNet Subnet")
        $AzureVirtualSubnetDropdown.SelectedItem = $AzureVirtualSubnetDropdown.Items[0]
        $AzureVirtualSubnetDropdown.Enabled = $false
    }
}

Function VirtualSubnetChange
{
    If($AzureVirtualSubnetDropdown.SelectedIndex -gt 0)
    {
        $Global:SubnetName = $AzureVirtualSubnetDropdown.SelectedItem
        $Global:SubnetPrefix = (Get-AzureRmVirtualNetworkSubnetConfig -VirtualNetwork  $Global:VNetSUbnetLevelNetwork -Name $Global:SubnetName -WarningAction SilentlyContinue).AddressPrefix
    }
}

Function EstimateCompute
{
    ### Clearing Form
    $Global:Form.Controls.Remove($SessionHostMachineSizeDropDown)
    $Global:Form.Controls.Remove($RDS_GW_WWW_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($RDS_GW_WWW__CB_LS_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_SF_DDC_SizeDropdown)
    $Global:Form.Controls.Remove($CTX_FS_SQL_Dropdown)
    $Global:Form.Controls.Remove($Server1TextBox)
    $Global:Form.Controls.Remove($Server1Label)
    $Global:Form.Controls.Remove($Server2TextBox)
    $Global:Form.Controls.Remove($Server2Label)
    $Global:Form.Controls.Remove($Server3TextBox)
    $Global:Form.Controls.Remove($Server3Label)

    ### Calcuating Session Hosts - This Vendor agnostic - Load based on Jump Box and VDI Users
    $JumpBoxusers =  $NonVDIUserTextBox.Text
    $VDIUsers = $VDIUserCountTextBox.Text
    $JumpBoxSessionHosts = [math]::Ceiling($JumpBoxusers / 50)
    $VDISessionHosts = [math]::Ceiling($VDIUsers / 25)
    $TotalSessionHosts = $VDISessionHosts + $JumpBoxSessionHosts


    Write-Host $TotalSessionHosts
    If($Global:RemoteAccessProvider -eq "Microsoft")
    {
        CreateTextBoxObject $Server1TextBox 30 145 20 15
        CreateTextBoxLabel $Server1Label 55 147.5 150 15 "RDS Session Host Role"

        ### Populating Session Host Text Box
        $Server1TextBox.Text = $TotalSessionHosts
        $Server2TextBox.Text = "1"
        $Server3TextBox.Text = "1"
        If($Global:ClientSize -eq "100 - 250" -or $Global:ClientSize -eq "250 - 1000")
        {
            CreateTextBoxObject $Server2TextBox 30 175 20 15
            CreateTextBoxLabel $Server2Label 55 177.5 150 15 "RDS WWW and GW Role"
            CreateTextBoxObject $Server3TextBox 30 205 20 15
            CreateTextBoxLabel $Server3Label 55 207.5 150 15 "RDS SB and LS Role"
            $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
            $Global:Form.Controls.Add($RDS_GW_WWW_SizeDropdown)
            $Global:Form.Controls.Add($RDS_CB_LS_SizeDropdown)
            $ComputeTextBoxFrame.SendToBack()
        }
        ELse
        {
            CreateTextBoxObject $Server2TextBox 30 175 20 15
            CreateTextBoxLabel $Server2Label 55 177.5 150 15 "RDS All Infrastructure Roles"
            $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
            $Global:Form.Controls.Add($RDS_GW_WWW__CB_LS_SizeDropdown)
            $ComputeTextBoxFrame.SendToBack()
        }
    }
    ELseIf($Global:RemoteAccessProvider -eq "Citrix")
    {
        CreateTextBoxObject $Server1TextBox 30 145 20 15
        CreateTextBoxLabel $Server1Label 55 147.5 150 15 "Citrix Session Host Role"
        CreateTextBoxObject $Server2TextBox 30 175 20 15
        CreateTextBoxLabel $Server2Label 55 177.5 150 15 "Citrix SF and DDC Role"
        CreateTextBoxObject $Server3TextBox 30 205 20 15
        CreateTextBoxLabel $Server3Label 55 207.5 150 15 "Citrix FS and SQL Role"

        ### Populating Session Host Text Box
        $Server1TextBox.Text = $TotalSessionHosts

        $Global:Form.Controls.Add($SessionHostMachineSizeDropDown)
        $Global:Form.Controls.Add($CTX_SF_DDC_SizeDropdown)
        $Global:Form.Controls.Add($CTX_FS_SQL_Dropdown)
        $ComputeTextBoxFrame.SendToBack()
        If($Global:ClientSize -eq "0 - 50")
        {
            $Server2TextBox.Text = "1"
            $Server3TextBox.Text = "1"
        }
        Else
        {
            $Server2TextBox.Text = "2"
            $Server3TextBox.Text = "1"
        }
    }
}



### Creating Form Objects in Order
CreateTextBoxLabel $InfrastructureLabel 20 20 200 15 "Remote Access Infrastructure"
CreateTextBoxLabel $AzureInfraLabel 20 375 200 15 "Azure VDI Components"

### Creating Text Box Frame for Compute Calculation
CreateTextBoxObject $ComputeTextBoxFrame 20 130 725 250
$ComputeTextBoxFrame.Multiline = $true
$ComputeTextBoxFrame.ReadOnly = $true
$ComputeTextBoxFrame.SendToBack()

### Create Dropdown Menus
CreateMachineSizingDropdowns
CreateRDSInfraDropdown
CreateUserCount
CreateSubscriptionDown
CreateResourceGroupDropDown
CreateVirtualNetworkDropDown
CreateVirtualSubnetDropDown

### Create CheckBoxes and Associated Labels
#CreateCheckBox $CaptureCheckbox 20 17.5
#CreateTextBoxLabel $CaptureLabel 40 22 110 15 "Capture User State Data"

#CreateCheckBox $RestoreCheckbox 180 17.5
#CreateTextBoxLabel $RestoreLabel 200 22 110 15 "Restore User State Data"

#CreateCheckBox $USBStorageCheckbox 20 47.5
#CreateTextBoxLabel $USBStorageLabel 40 47.5 110 15 "Use USB Storage"


### Create Textboxes and Associated Labels
CreateTextBoxObject $VDIUserCountTextBox 20 95 40 15
CreateTextBoxLabel $VDIUserCountLabel 65 97.5 90 15 "VDI User Count"

CreateTextBoxObject $NonVDIUserTextBox 160 95 40 15
CreateTextBoxLabel $NonVDIUserCountLabel 205 97.5 120 15 "Jump Box User Count"

### Create Buttons
CreateButton $EstimateComputeButton 325 95 100 20 "Calculate Compute Needs"
#CreateButton $Global:ResetForm 130 185 100 20 "Reset Form"
#CreateButton $Global:Continue 240 185 100 20 "Continue"
#CreateButton $Global:ExitBUtton 350 185 100 20 "Exit"

### Checkbox Behaviors
#$CaptureCheckbox.Add_CheckStateChanged({CaptureCheckBoxActions})
#$RestoreCheckbox.Add_CheckStateChanged({RestoreCheckBoxActions})
#$USBStorageCheckbox.Add_CheckStateChanged({USBCheckBoxActions})


### DropDown Menu Change Actions
$RDSInfraTypeDropdown.Add_SelectedValueChanged({RDSInfraDropDownChange})
$AzureSubscriptionsDropdown.Add_SelectedValueChanged({SubscriptionDropDownChange})
$AzureResourceGroupDropdown.Add_SelectedValueChanged({ResourceGroupChange})
$AzureVirtualNetworkDropdown.Add_SelectedValueChanged({NetworkGroupChange})
$AzureVirtualSubnetDropdown.Add_SelectedValueChanged({VirtualSubnetChange})
$UserCountDropdown.Add_SelectedValueChanged({UserCountChange})


### Button Actions
$EstimateComputeButton.Add_Click({EstimateCompute})


$Global:Form.Add_Shown({$Global:Form.Activate()})
[void] $Global:Form.ShowDialog()
