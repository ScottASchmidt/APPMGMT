﻿-----------
#First, connect to AzureRM Account
Connect-AzureRMAccount

#General Variables - update all of these before running this script!
$ResourceGroupName='RSG-COVID19-Response'																					#Get-AzureRmResourceGroup |select resourcegroupname, location |format-table
$LocationName='northcentralus'																								#Get-AzureRmResourceGroup |select resourcegroupname, location |format-table
$vNet='vnetCOVID19-Response'																								#Get-AzureRmVirtualNetwork | select Name
$vNetPrefix='10.20.28.0/22'																									#Get-AzureRmVirtualNetwork |fl #and look at the AddressSpace
$vNetSubnet='AzureVMSubnet'																									#Get-AzureRmVirtualNetwork | Get-AzureRmVirtualNetworkSubnetConfig | format-table
$vNetSubnetPrefix='10.20.29.0/24'																							#Get-AzureRmVirtualNetwork |Get-AzureRmVirtualNetworkSubnetConfig -Name $vNetSubnet
$vNetSubnetID=Get-AzureRmVirtualNetwork | Get-AzureRmVirtualNetworkSubnetConfig -Name $vNetSubnet							#This line gets the Subnet ID for later scripting
$VMLocalAdminUser='FMLocalAdmin'																							#replace the text between the single quotes with the desired VM local admin username
$VMLocalAdminSecurePassword = ConvertTo-SecureString 'DkKMfjjBmTubcQS!@QByxo' -AsPlainText -Force							#replace the text between the single quotes with the desired VM local admin password
$Credential = New-Object System.Management.Automation.PSCredential ($VMLocalAdminUser, $VMLocalAdminSecurePassword);
$RDSSHCount='12'
$RDSGWVMSize='Standard_F4'
$RDSSHVMSize="Standard_D4_v2"


#RDSGW variables
$RDSGWComputerName='RDSGW1'
$RDSGWNICName = 'vNIC-RDSGW1'
$RDSGWNIC = New-AzureRMNetworkInterface -name $RDSGWNICName -ResourceGroupName $ResourceGroupName -Location $LocationName -SubnetId $vNetSubnetID.Id

#Create RDSGW config
$VirtualMachine = New-AzureRmVMConfig -VMName $RDSGWComputerName -VMSize $RDSGWVMSize
$VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $RDSGWComputerName -Credential $Credential -ProvisionVMAgent -EnableAutoUpdate
$VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $RDSGWNIC.Id
$VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName 'MicrosoftWindowsServer' -Offer 'WindowsServer' -Skus '2019-Datacenter' -Version latest

#Deploy RDSGW
New-AzureRmVM -ResourceGroupName $ResourceGroupName -Location $LocationName -VM $VirtualMachine -Verbose


#For loop to deploy $RDSSHCount Session hosts of type $RDSSHVMSize
1..$RDSSHCount | ForEach {
	$RDSSHName="RDSSH$_"
	$RDSSHNICName="vNIC-RDSSH$_"
	$RDSSHNIC=New-AzureRMNetworkInterface -name $RDSSHNICName -ResourceGroupName $ResourceGroupName -Location $LocationName -SubnetId $vNetSubnetID.Id
	
	$VirtualMachine = New-AzureRmVMConfig -VMName $RDSSHName -VMSize $RDSSHVMSize
	$VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $RDSSHName -Credential $Credential -ProvisionVMAgent -EnableAutoUpdate
	$VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $RDSSHNIC.Id
	$VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName 'MicrosoftWindowsServer' -Offer 'WindowsServer' -Skus '2019-Datacenter' -Version latest
	
	New-AzureRmVM -ResourceGroupName $ResourceGroupName -Location $LocationName -VM $VirtualMachine -Verbose