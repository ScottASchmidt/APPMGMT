﻿### Setting Launch Params
param(
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$AzureUserName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$TenantName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][ValidateSet("True", "False")][String]$HighRes
)

### Enable-AzureRMAlias allows for Legacy AzureRM Cmdlets to be used
Enable-AzureRMAlias

#$ErrorActionPreference = "SilentlyContinue"
$CurrentDirectory = $PSScriptRoot
$TitleICO = New-Object system.drawing.icon ("$CurrentDirectory\MSLogo.ico")

### Always Add These to PowerShell Forms
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationFramework

### If HighRes Screen is set the form multiplier will be reset to accomodate a larger size
If($HighRes -eq "True")
{
    $Global:XMultiplier=2
    $Global:yMultiplier=2
}
Else
{
    $Global:XMultiplier=1
    $Global:yMultiplier=1
}



### Setting Up PowerShell Form
$Global:Form = New-Object System.Windows.Forms.Form    
$Global:Form.Size = New-Object System.Drawing.Size((1024*$Global:XMultiplier),(800*$Global:yMultiplier))  
$Global:Form.Text = "Lab Hydration Utility"  
$Global:ClientName = "Microsoft"
$Global:Form.BackColor = "#00a3ee"
$Global:Form.Icon = $TitleICO

### Authenticating to Graph / Tenant
function Get-AuthToken
{
    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )

    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    $tenant = $userUpn.Host

    Write-Host "Checking for AzureAD module..."

    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($AadModule -eq $null)
    {
        Write-Host "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }

    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    $resourceAppIdURI = "https://graph.microsoft.com"
    $authority = "https://login.microsoftonline.com/$Tenant"

    try {
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
        # https://msdn.microsoft.com/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
        # If the accesstoken is valid then create the authentication header
        if ($authResult.AccessToken) {
            # Creating header for Authorization token
            $authHeader = @{
                'Content-Type' = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn' = $authResult.ExpiresOn
            }
            return $authHeader
        }
        else {
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
        }
    }
    catch {
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    }   
}

### Connecting to Azure
$Global:authToken = Get-AuthToken -User $AzureUserName

######### Creating Form Objects #########
### Creating Label Objects
$NewRGLabel = New-Object System.Windows.Forms.Label
$NewVNetLabel = New-Object System.Windows.Forms.Label
$NewSubnetLabel = New-Object System.Windows.Forms.Label
$NewRGNameLabel = New-Object System.Windows.Forms.Label
$NewVNetNameLabel = New-Object System.Windows.Forms.Label 
$NewVNetDescriptionLabel = New-Object System.Windows.Forms.Label

### Creating Drop Down Menu
$AzureSubscriptionsDropdown = New-Object System.Windows.Forms.ComboBox
$AzureResourceGroupDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualNetworkDropdown = New-Object System.Windows.Forms.ComboBox
$AzureVirtualSubnetDropdown = New-Object System.Windows.Forms.ComboBox
$AzureLocationDropdown = New-Object System.Windows.Forms.ComboBox
$AzureDMachineDropdown = New-Object System.Windows.Forms.ComboBox
$AzureBMachineDropdown = New-Object System.Windows.Forms.ComboBox
$AzureLocationDropDown = New-Object System.Windows.Forms.ComboBox
$NewVNetDropDown = New-Object System.Windows.Forms.ComboBox

### Creating Text Box Objects
$ResourceGroupNameTextBox = New-Object System.Windows.Forms.TextBox
$NewVNetNameTextBox = New-Object System.Windows.Forms.TextBox

### Creating Buttons
$CreateNewRGButton = New-Object System.Windows.Forms.Button 
$VerifyNewRGButton = New-Object System.Windows.Forms.Button 
$CreateNewVNetButton = New-Object System.Windows.Forms.Button 
$VerifyNewVNetButton = New-Object System.Windows.Forms.Button 

### Creating Checkbox Objects
$NewRGCheckBox = new-object System.Windows.Forms.checkbox
$NewVnetCheckBox = new-object System.Windows.Forms.checkbox
$NewSubNetCheckBox = new-object System.Windows.Forms.checkbox

######### Functions for Creating Form Objects #########

### Function to Create DropDown Menus
Function CreateDropDownMenus($DropdownObject,$PosX,$PosY,$BoxLen,$BoxHeight,$MenuHeight,$TextforFirstItem)
{
    $DropdownObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $DropdownObject.Size = new-object System.Drawing.Size($BoxLen,$BoxHeight)
    $DropdownObject.DropDownHeight = 300
    $DropdownObject.Enabled = $False
    $DropdownObject.Items.Add($TextforFirstItem)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
    $DropdownObject.BringToFront()
    $DropdownObject.Font = New-Object System.Drawing.Font("Lucida Console",(9*$XMultiplier),[System.Drawing.FontStyle]::Regular)
    $Form.Controls.Add($DropdownObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $CheckBoxObject.enabled = $false
    $CheckBoxObject.margin = "0,0,0,0"
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Text Labels
Function CreateTextBoxLabel($TextBoxLabel,$PosX,$PosY,$BoxLen,$BoxHeight,$Title)
{
    $TextBoxLabel.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxLabel.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxLabel.Text = $Title
    $TextBoxLabel.BringToFront()
    #$TextBoxLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $Global:form.Controls.Add($TextBoxLabel)
}

### Function to Create Text Box 
Function CreateTextBoxObject($TextBoxObject,$PosX,$PosY,$BoxLen,$BoxHeight)
{
    #Write-host $BoxHeight
    $TextBoxObject.Location = New-Object System.Drawing.Point($PosX,$PosY)
    $TextBoxObject.Size = New-Object System.Drawing.Size($BoxLen,$BoxHeight)
    $TextBoxObject.BringToFront()
    $Global:form.Controls.Add($TextBoxObject)
}

### Function to Create Check Box
Function CreateCheckBox($CheckBoxObject,$PosX,$PosY)
{
    $CheckBoxObject.Location = new-object System.Drawing.Size($PosX,$PosY)
    $CheckBoxObject.Size = new-object System.Drawing.Size(20,20)
    $CheckBoxObject.Checked = $False
    $CheckBoxObject.BringToFront()
    $Form.Controls.Add($CheckBoxObject)
}

### Function to Create Buttons
Function CreateButton($ButtonObject,$PosX,$PosY,$ButtonLen,$ButtonHeight,$ButtonText,$Type)
{  
    $ButtonObject.Location = New-Object System.Drawing.Size($PosX,$PosY) 
    $ButtonObject.Size = New-Object System.Drawing.Size($ButtonLen,$ButtonHeight) 
    #$ButtonObject.Font = $Global:High_DPIScale_Font
    $ButtonObject.Text = $ButtonText
    $ButtonObject.BringToFront()
    $ButtonObject.Backcolor = "#7eb801"
    #$ButtonObject.ForeColor = "#FFFFFF"
    $ButtonObject.FlatStyle = [system.windows.forms.FlatStyle]::Flat
    $ButtonObject.FlatAppearance.BorderColor = [System.Drawing.Color]::Gray
    $ButtonObject.FlatAppearance.BorderSize = (1*$XMultiplier)
    $ButtonObject.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    If($Type -eq "Validate")
    {
        $ValidationButtonImage = [system.drawing.image]::FromFile("$CurrentDirectory\ResizedValidate.png")
        $ButtonObject.image = $ValidationButtonImage
    }
    If($Type -eq "Create")
    {
        $CreateButtonImage = [system.drawing.image]::FromFile("$CurrentDirectory\ResizedCreate.png")
        $ButtonObject.image = $CreateButtonImage
    }
    $ButtonObject.font = New-Object System.Drawing.Font("Calibri",(9*$XMultiplier),[System.Drawing.FontStyle]::Regular)
    $Form.Controls.Add($ButtonObject)
}

####### Populating DropdownMenus #######
### Populating Resource Group DropDown -This change is initiated from a change in the subscription dropdown
Function SortDropDownMenu($DropdownObject)
{
    $DropdownObject.Enabled = $true
    $DropdownObject.Sorted = $true
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function ClearDropDownMenu($DropdownObject,$FirstLineText)
{
    $DropdownObject.Items.Clear()
    $DropdownObject.Items.Add($FirstLineText)
    $DropdownObject.SelectedItem = $DropdownObject.Items[0]
}

Function SubscriptionDropDownChange
{
    If($AzureSubscriptionsDropdown.SelectedIndex -gt 0)
    {
        $NewRGCheckBox.Enabled = $True
        $Global:SubscriptionName = $AzureSubscriptionsDropdown.SelectedItem
        Select-AzSubscription -subscription $Global:SubscriptionName

        ### Populating Azure Resource Groups
        ClearDropDownMenu $AzureResourceGroupDropdown "- Choose Azure Resource Group -"

        $AzureResourceGroups = Get-AZResourceGroup |select resourcegroupname,location
        ForEach($ResourceGroup in $AzureResourceGroups)
        {
            $ResourceGroupText = $ResourceGroup.ResourceGroupName + " (" + $ResourceGroup.Location + ")"
            $AzureResourceGroupDropdown.Items.Add($ResourceGroupText)
        }
        SortDropDownMenu $AzureResourceGroupDropdown
    }
    Else
    {
        $NewRGCheckBox.Enabled = $false
        ClearDropDownMenu $AzureResourceGroupDropdown "- Choose Azure Resource Group -"
    }
}


### Populating VNet Dropdown - Based on Resource Group Selection Changes
Function ResourceGroupChange
{
    If($AzureResourceGroupDropdown.SelectedIndex -gt 0)
    {
        $NewVnetCheckBox.Enabled = $True
        [string]$ResourceGroup = $AzureResourceGroupDropdown.SelectedItem
        $LocationCount = $ResourceGroup.IndexOf(' (' )
        #$ResourceLocationLength = $ResourceGroup.Length - ($LocationCount + 11)
        $Global:ResourceGroupName = $ResourceGroup.Substring(0,$LocationCount)

        ### Populating Network Dropdown Info
        ClearDropDownMenu $AzureVirtualNetworkDropdown "- Choose Azure Virtual Network -"
         
        $AzureVirtualNetworks = Get-AzVirtualNetwork -WarningAction SilentlyContinue -ResourceGroupName $Global:ResourceGroupName
        ForEach($Network in $AzureVirtualNetworks)
        {
           $AzureVirtualNetworkDropdown.Items.Add($Network.Name)
        }
        SortDropDownMenu $AzureVirtualNetworkDropdown
        ### Setting this variable to track location change between functions
        #$Global:LastCheckResouceGroupLocation = $Global:ResourceGroupLocation
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualNetworkDropdown "- Choose Azure Virtual Network -"
    }
}

### VNet Network
Function NetworkGroupChange
{
    IF($AzureVirtualNetworkDropdown.SelectedIndex -gt 0)
    {
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
        $AzureVirtualNetworks = Get-AzVirtualNetwork
        ForEach($Network in $AzureVirtualNetworks)
        {
            $AZResourceGroup = $Network.ResourceGroupName 
            $AZResrouceName = $Network.Name
            If($AZResrouceName -eq $AzureVirtualNetworkDropdown.SelectedItem)
            {
                $Location = $Network.Location
                $VNetPreFix = $Network.AddressSpace.AddressPrefixes
                #$VNET = Get-AzVirtualNetwork -ResourceGroupName $AZResourceGroup -Name $AZResrouceName
                $SubnetList = $Network.Subnets
                ForEach($Prefix in $SubnetList)
                {
                    $SubnetText = $Prefix.Name + " (" + $Prefix.AddressPrefix + ")"
                    $AzureVirtualSubnetDropdown.Items.Add($SubnetText)
                }
            }
        }
        SortDropDownMenu $AzureVirtualSubnetDropdown
        ### Retrieving VM Types from the Azure Data Center specified in the Network Location
        GetAZMachinesTypes $Location
    }
    Else
    {
        ClearDropDownMenu $AzureVirtualSubnetDropdown "Choose Subnet"
    }
}


### Getting Azure Machine Types
Function GetAZMachinesTypes($Location)
{
    $AZMachineArray = Get-AzVmSize -Location $Location
    $Global:DClassTable = @{}
    $Global:BClassTable = @{}
    ForEach($MachineType in $AZMachineArray)
    {
        ### Creating D Class Machine Array
        IF($MachineType.Name -like "Standard_D*V5")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
             $Global:DClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }

        ### Creating B Class Machine Array
        IF($MachineType.Name -like "Standard_B*")
        {
            [string]$Name =  $MachineType.Name
            [string]$RAM = $MachineType.MemoryInMB
            [string]$CPU = $MachineType.NumberOfCores
            $Global:BClassTable += @{$Name = [PSCustomObject]@{RAM=$RAM;CPU=$CPU}}
        }
    }
    Write-Host $Global:BClassTable["Standard_B2s"].RAM
}

### Getting Azure DataCenter Locations
Function GetAZLocations
{
    CreateDropDownMenus $AzureLocationDropDown (20*$XMultiplier) (220*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose AZ DataCenter Location -"
    $AzureLocationDropDown.Hide()
    $AZLocationArray = Get-AzLocation | Sort-Object DisplayName
    $Global:LocationTable = @{}
    ForEach($GeoLocation in $AZLocationArray)
    {
        [string]$Name = $GeoLocation.DisplayName
        [string]$LocationString = $GeoLocation.Location
        $Global:LocationTable += @{$Name = [PSCustomObject]@{LOCATION=$LocationString}}
        $AzureLocationDropDown.Items.Add($Name)
        SortDropDownMenu $AzureLocationDropDown
    }
    Write-Host $Global:LocationTable["West US 2"].LOCATION
    #Write-Host $BClassTable.Name
}

#### Creating New ResourceGroup form Objects - From CheckBox Click
Function CreateNewRGObects($checkstate)
{
    If($checkstate -eq "Checked")
    {
        $AzureVirtualNetworkDropdown.Enabled = $False
        $NewVnetCheckBox.Enabled = $False
        $AzureResourceGroupDropdown.Enabled = $false
        CreateTextBoxLabel $NewRGNameLabel (20*$XMultiplier) (160*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Resource Group Name"
        CreateTextBoxObject $ResourceGroupNameTextBox (20*$XMultiplier) (180*$yMultiplier) (300*$XMultiplier) (20*$XMultiplier)
        CreateButton $VerifyNewRGButton (20*$XMultiplier) (260*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Verify Resource Group" "Validate"
        CreateButton $CreateNewRGButton (20*$XMultiplier) (310*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Create Resource Group" "Create"
        $CreateNewRGButton.Enabled = $False
        $CreateNewRGButton.BackColor = "#aba7a7"
        $NewRGNameLabel.Show()
        $ResourceGroupNameTextBox.show()
        $AzureLocationDropDown.Enabled = $true
        $AzureLocationDropDown.Show()
        $CreateNewRGButton.Show()
        $VerifyNewRGButton.Show()
    }
    Else
    {
        $NewRGNameLabel.hide()
        $ResourceGroupNameTextBox.Clear()
        $ResourceGroupNameTextBox.Hide()
        $AzureLocationDropDown.Enabled = $false
        $AzureLocationDropDown.Hide()
        $AzureLocationDropDown.SelectedIndex[0]
        $AzureResourceGroupDropdown.Enabled = $true
        $CreateNewRGButton.hide()
        $VerifyNewRGButton.hide()
    } 

}

Function VerifyRG
{
    ### Resetting Items to enabled state
    $ResourceGroupNameTextBox.Enabled = $true
    $CreateNewRGButton.Enabled = $False
    $VerifyNewRGButton.Enabled = $True

    $ValidationPassed = $False
    If($ResourceGroupNameTextBox.Text -NE "")
    {
        If(Get-AzResourceGroup -Name $ResourceGroupNameTextBox.Text -ErrorAction SilentlyContinue)
        {
            
            [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " already exists. Press OK to try again.",'Resource Group Validation','OK','Error')
        }
        else
        {
            ### Checking for special Characters and Spaces
            If(($ResourceGroupNameTextBox.Text -match '[^a-zA-Z0-9^-]') -eq $True)
            {
                [System.Windows.MessageBox]::Show("The Resource Group cannot contain spaces or special characters.`nPress OK to try again.",'Location Validation','OK','Error')
            }
            Else
            {
                If($AzureLocationDropDown.SelectedIndex -eq 0)
                {
                    $LocationSelectionMsgText = "Location is not selected, press OK to continue and select a Location."
                    [System.Windows.MessageBox]::Show( $LocationSelectionMsgText,'Location Validation','OK','Error')
                }
                Else
                {
                    $LocationSelectionMsgText = "Verify that " + $AzureLocationDropDown.Text + " is the correct location."
                    $ValidationPassed = [System.Windows.MessageBox]::Show($LocationSelectionMsgText + "`nThe Resource Group " + $ResourceGroupNameTextBox.Text + " has passed Validation. Press Yes to Continue or No to Go Back",'Resource Group Validation','YesNo','Question')
                }
            }
        }
    }
    Else
    {
        [System.Windows.MessageBox]::Show("The Resource Group Name Field cannot be left bank. Press OK to try again.",'Resource Group Validation','OK','Error')
    }
    
    If($ValidationPassed -eq "Yes")
    {
        $VerifyNewRGButton.Enabled = $False
        $CreateNewRGButton.Enabled = $true
        $ResourceGroupNameTextBox.Enabled = $False
        $VerifyNewRGButton.BackColor = "#aba7a7"
        $CreateNewRGButton.BackColor = "#7eb801"
    }
    Else
    {
        $ResourceGroupNameTextBox.Enabled = $true
        $CreateNewRGButton.Enabled = $False
    }
}

Function CreateNewRG
{
    [String]$RGNameText = $ResourceGroupNameTextBox.Text

    New-AzResourceGroup -Name $RGNameText -Location $AzureLocationDropDown.Text
    If(Get-AzResourceGroup -Name $ResourceGroupNameTextBox.Text -ErrorAction SilentlyContinue)
    {
        $CreateRG = [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " has been successfully created.`nIf you are finished creating creating resource groups, press Yes to close form and continue or `npress No to create another resource Group.",'Resource Group Creation','YesNo','Question')
    }
    else
    {
        [System.Windows.MessageBox]::Show("The Resource Group " + $ResourceGroupNameTextBox.Text + " failed to create. Press OK to try again.",'Resource Group Creation','Ok','Error')
        $ResourceGroupNameTextBox.Enabled = $true
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
    }

    If($CreateRG -eq "Yes")
    {
        SubscriptionDropDownChange
        $NewRGCheckBox.Checked = $False
        $ResourceGroupNameTextBox.Enabled = $true
        $ResourceGroupNameTextBox.Clear()
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
    }
    Else
    {
        $ResourceGroupNameTextBox.Enabled = $true
        $ResourceGroupNameTextBox.Clear()
        $CreateNewRGButton.Enabled = $False
        $VerifyNewRGButton.Enabled = $True
        $AzureLocationDropDown.SelectedIndex = 0
        SubscriptionDropDownChange
        CreateNewRGObects "Checked"
    }
}

#### Creating New VNet form Objects - From CheckBox Click
Function CreateVNetObects($checkstate)
{
    If($checkstate -eq "Checked")
    {
        $AzureVirtualNetworkDropdown.Enabled = $False
        CreateTextBoxLabel $NewVNetNameLabel (340*$XMultiplier) (160*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Virtual Network Name"
        CreateTextBoxObject $NewVNetNameTextBox (340*$XMultiplier) (180*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier)
        CreateDropDownMenus $NewVNetDropDown (340*$XMultiplier) (250*$yMultiplier) (200*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose VNet Prefix -"
        CreateTextBoxLabel $NewVNetDescriptionLabel (340*$XMultiplier) (220*$yMultiplier) (200*$xMultiplier) (20*$yMultiplier) "Class B VNets are used for Simplicity"
        CreateButton $VerifyNewVNetButton (340*$XMultiplier) (290*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Verify New VNet" "Validate"
        CreateButton $CreateNewVNetButton (340*$XMultiplier) (340*$yMultiplier) (200*$XMultiplier) (40*$xMultiplier) "Create New VNet" "Create"
        $NewVNetNameLabel.Show()
        $NewVNetNameTextBox.Show()
        $NewVNetDropDown.Show()
        $NewVNetDescriptionLabel.Show()
        $VerifyNewVNetButton.Show()
        $CreateNewVNetButton.Show()
        $CreateNewVNetButton.Enabled = $False
        $CreateNewVNetButton.BackColor = "#aba7a7"
        $NewVNetDropDown.enabled = $true
        ### Retrieving Subnets to be used for duplicate checking when building the dropdown
        $VNetAddressList = (Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName).AddressSpace.AddressPrefixes
        #### Populatng dropdown menu
        $VNETCreateCheck = 1
        $VNETFirstOctet = 10
        DO
        {
            $VnetString = [string]$VNETFirstOctet + '.0.0.0/16'
            $Match = $false
            ForEach($Address in $VNetAddressList)
            {
                [String]$VNetFromArray = $Address
                If($VnetString -eq $VNetFromArray)
                {
                    $Match = $True
                    $VNETFirstOctet++
                }
            }
            If($Match -eq $false)
            {
                $NewVNetDropDown.Items.Add($VnetString)
                $VNETFirstOctet++
                $VNETCreateCheck++
            }            
        } Until ($VNETCreateCheck -gt 10)
        SortDropDownMenu $NewVNetDropDown
    }
    Else
    {
        $AzureVirtualNetworkDropdown.Enabled = $True
        $NewVNetDropDown.Items.Clear()
        $NewVNetNameLabel.Hide()
        $NewVNetNameTextBox.Hide()
        $NewVNetDropDown.Hide()
        $NewVNetDescriptionLabel.Hide()
        $VerifyNewVNetButton.Hide()
        $CreateNewVNetButton.Hide()
    } 
}

Function VerifyVNet
{
    ### Resetting Items to enabled state
    $NewVNetNameTextBox.Enabled = $true
    $CreateNewVNetButton.Enabled = $False
    $VerifyNewVNetButton.Enabled = $True

    $ValidationPassed = $False
    If($NewVNetNameTextBox.Text -NE "")
    {
        if(Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $NewVNetNameTextBox.Text -ErrorAction SilentlyContinue)
        {
            
            [System.Windows.MessageBox]::Show("The VNet " + $NewVNetNameTextBox.Text + " already exists. Press OK to try again.",'Virtual Network Validation','OK','Error')
        }
        else
        {
            ### Checking for special Characters and Spaces
            If(($NewVNetNameTextBox.Text -match '[^a-zA-Z0-9^-]') -eq $True)
            {
                [System.Windows.MessageBox]::Show("The VNet Name cannot contain spaces or special characters.`nPress OK to try again.",'Virtual Network Validation','OK','Error')
            }
            Else
            {
                If($NewVNetDropDown.SelectedIndex -eq 0)
                {
                    $VNetSelectionMsgText = "VNet Address Prefix is not selected, press OK to continue and select a VNet Address Prefix."
                    [System.Windows.MessageBox]::Show($VNetSelectionMsgText,'Virtual Network Validation','OK','Error')
                }
                Else
                {
                    $VNetSelectionMsgText = "Verify that " + $NewVNetDropDown.Text + " is the correct Address Prefix."
                    $ValidationPassed = [System.Windows.MessageBox]::Show($VNetSelectionMsgText + "`nThe Virtual Network " + $ResourceGroupNameTextBox.Text + " has passed Validation. Press Yes to Continue or No to Go Back",'Virtual Network Validation','YesNo','Question')
                }
            }
        }
    }
    Else
    {
        [System.Windows.MessageBox]::Show("The New VNet Group Name Field cannot be left bank. Press OK to try again.",'Virtua; Network Validation','OK','Error')
    }
    
    If($ValidationPassed -eq "Yes")
    {
        $VerifyNewVNetButton.Enabled = $False
        $CreateNewVNetButton.Enabled = $true
        $NewVNetNameTextBox.Enabled = $False
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
    }
    Else
    {
        $NewVNetNameTextBox.Enabled = $true
        $CreateNewVNetButton.Enabled = $False
    }

}

Function CreateNewVNet
{
    [String]$VNetNameText = $NewVNetNameTextBox.Text
    $RGLocation = (Get-AzResourceGroup -Name $Global:ResourceGroupName).Location
    New-AzVirtualNetwork -Name $VNetNameText -ResourceGroupName $Global:ResourceGroupName -Location $RGLocation -AddressPrefix $NewVNetDropDown.Text
    If(Get-AzVirtualNetwork -ResourceGroupName $Global:ResourceGroupName -Name $VNetNameText -ErrorAction SilentlyContinue)
    {
        $CreateVNet = [System.Windows.MessageBox]::Show("The VNet " + $VNetNameText + " has been successfully created.`nIf you are finished creating creating VNets, press Yes to close form and continue or `npress No to create another VNet.",'Virutal Network Creation','YesNo','Question')
    }
    else
    {
        [System.Windows.MessageBox]::Show("The VNet " + $VNetNameText + " failed to create. Press OK to try again.",'Virutal Network Creation','Ok','Error')
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $NewVNetNameTextBox.Enabled = $true
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
    }

    If($CreateVNet -eq "Yes")
    {
        ResourceGroupChange
        $NewVnetCheckBox.Checked = $False
        $NewVNetNameTextBox.Enabled = $true
        $NewVNetNameTextBox.Clear()
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
    }
    Else
    {
        $NewVNetNameTextBox.Enabled = $true
        $NewVNetNameTextBox.Clear()
        $VerifyNewVNetButton.BackColor = "#aba7a7"
        $CreateNewVNetButton.BackColor = "#7eb801"
        $CreateNewVNetButton.Enabled = $False
        $VerifyNewVNetButton.Enabled = $True
        ResourceGroupChange
        $NewVNetDropDown.Items.Clear()
        CreateVNetObects "Checked"
        $NewVNetDropDown.SelectedItem = 0
    }
}
#### Creating Form Objects
### Creating Dropdown Menus
CreateDropDownMenus $AzureSubscriptionsDropdown (20*$XMultiplier) (20*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Subscription -"
CreateDropDownMenus $AzureResourceGroupDropdown (20*$XMultiplier) (120*$yMultiplier) (300*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Resource Group -"
CreateDropDownMenus $AzureVirtualNetworkDropdown (340*$XMultiplier) (120*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure VNet -"
CreateDropDownMenus $AzureVirtualSubnetDropdown (610*$XMultiplier) (120*$yMultiplier) (250*$XMultiplier) (20*$XMultiplier) (300*$XMultiplier) "- Choose Azure Subnet -"

### Creating Text Labels
CreateTextBoxLabel $NewRGLabel (40*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Resource Group"
CreateTextBoxLabel $NewVNetLabel (360*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Vnet"
CreateTextBoxLabel $NewSubnetLabel (630*$XMultiplier) (82.5*$yMultiplier) (200*$xMultiplier) (15*$yMultiplier) "Create New Subnet"

### Creating Buttons

### Populating Azure Subscriptions
$AzureSubscriptionsDropdown.Enabled = $true
$AzureSubscriptions = get-azsubscription | select name
ForEach($Subscription in $AzureSubscriptions){$AzureSubscriptionsDropdown.Items.Add($Subscription.Name)}
$AzureSubscriptionsDropdown.Sorted = $true
$AzureSubscriptionsDropdown.SelectedItem = $AzureSubscriptionsDropdown.Items[0]

### Creating CheckBox
CreateCheckBox $NewRGCheckBox (20*$XMultiplier) (80*$yMultiplier)
$NewRGCheckBox.Enabled = $false
$NewRGCheckBox.BringToFront()
CreateCheckBox $NewVnetCheckBox (340*$XMultiplier) (80*$yMultiplier)
$NewVnetCheckBox.Enabled = $false
CreateCheckBox $NewSubNetCheckBox (610*$XMultiplier) (80*$yMultiplier)
$NewSubNetCheckBox.Enabled = $false

### Populating AZ Locations Table
GetAZLocations
#CreateNewRGObects

### Dropdown Change Actions
$AzureSubscriptionsDropdown.Add_SelectedValueChanged({SubscriptionDropDownChange})
$AzureResourceGroupDropdown.Add_SelectedValueChanged({ResourceGroupChange})
$AzureVirtualNetworkDropdown.Add_SelectedValueChanged({NetworkGroupChange})

### CheckBox State Change Actions

$NewVnetCheckBox.Add_CheckStateChanged({CreateVNetObects $NewVnetCheckBox.CheckState})
$NewRGCheckBox.Add_CheckStateChanged({CreateNewRGObects $NewRGCheckBox.CheckState})

### Button Click Actions
$VerifyNewRGButton.Add_Click({VerifyRG})
$CreateNewRGButton.Add_Click({CreateNewRG})
$VerifyNewVNetButton.Add_Click({VerifyVNet})
$CreateNewVNetButton.Add_Click({CreateNewVNet})


### Presenting Windows Form
$Global:Form.Add_Shown({$Global:Form.Activate()})
[void] $Global:Form.ShowDialog() 