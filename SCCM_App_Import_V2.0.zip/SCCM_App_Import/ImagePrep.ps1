﻿#Requires -RunAsAdministrator
Cls

$ErrorActionPreference = 'stop'
Write-Host "`n`n`n`n``n"

#//
#// Add .NET Framework Feature and Remove Unwanted Provisioned Apps
#//

$ImageSource ='I:\Source\OS_Source\Win10x64_1909'
$ImageIndex = 3
$ImageStage = 'I:\Source\OS_Source\Image_Update'
$netfx = 'microsoft-windows-netfx3-ondemand-package~31bf3856ad364e35~amd64~~.cab'
$RemoveApps = ('Getstarted','Messaging','OfficeHub','Solitaire','OneConnect','People','SkypeApp','Communications','FeedbackHub','Xbox','Zune','bing','3D','Mixer','GetHelp','GetStarted','Wallet','MixedReality','SoundRecorder','Phone')

#// Global variables
$original = "$ImageStage\install-original.wim"
$wim = "$ImageStage\install-serviced.wim"
$final = "$ImageStage\install-final.wim"
$mountdir = "$env:temp\Win10ImageMount"
$sxs = "$ImageSource\Sources\sxs"

#// Create temp folder if it doesn't exist
If (!(Test-Path $mountdir)) {MD $mountdir}

#// Create Local copy of install.wim
If ((Test-Path $original)) {
    Write-Host "$original - already copied"
} Else {
    Write-Host "Copying '$ImageSource\sources\install.wim' to '$original'..."
    Try {
        Copy-Item "$ImageSource\sources\install.wim" $original
    } Catch {
        Write-Host "Copy FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
        Exit
    }
}


#// Export desired image to staged wim (filtering out duplicate indexes)
Write-Host "Export '$original' to '$wim' for index '$imageindex"

Try {
    Export-WindowsImage -SourceImagePath $original -SourceIndex $ImageIndex -DestinationImagePath $wim
} Catch {
    Write-Host "Export FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}

#// Mount Windows image - Index 1 after export
Write-Host "Mounting '$wim' to '$mountdir'"
Try {
    Mount-WindowsImage -Path $mountdir -ImagePath $wim -Index 1
    Write-Host "Mounted!"
} Catch {
    Write-Host "Mount FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}

Write-Host "Getting provisioned packages..."
$Packages= Get-AppxProvisionedPackage -Path $mountdir
WRite-Host "Appx Packages: $($Packages.Count).  Removing unwanted apps..."

Try {
    ForEach ($App in $RemoveApps) {
        Write-Host " * Removing $app..."
        Get-AppxProvisionedPackage -Path $mountdir | Where DisplayName -like "*$App*" | Remove-AppxProvisionedPackage
    }
} Catch {
    Write-Host "Remove AppX Package FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}

 

#//Add the latest monthly rollup
$Updates = ls "$ImageStage\Updates\*.msu" | Sort Name

Write-Host "Adding $($Updates.Count) updates to Windows 10"
Try {

    ForEach ($u in $Updates) {
        Write-Host "Adding $($u.Name)"
        Add-WindowsPackage -PackagePath "$ImageStage\Updates\$($u.Name)" -Path $mountdir
        Write-Host "Added"
    }

} Catch {
    Write-Host "Windows 10 update FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}

 

#//Add .NET Framework 3.5
Write-Host "Add .NET Framework 3.5 package..."

Try {
    Add-WindowsPackage -Path $mountdir -PackagePath "$sxs\$netfx"
    Write-Host ".NET added."

} Catch {
    Write-Host ".NET Add Failed FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}

#// Export the image contents prior to saving
Get-AppxProvisionedPackage -Path $mountdir | Out-File "$ImageStage\Win10-Appx.csv" -Force
Get-WindowsPackage -Path $mountdir | Out-File "$ImageStage\Win10-Package.csv" -Force

#//Unmount Image
Write-Host "Unmount image and save..."

Try {
    Dismount-WindowsImage -Path $mountdir -Save -CheckIntegrity
    Write-Host "Unmounted."
} Catch {
    Write-Host "Unmount FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}


#// Export desired image final WIM (filtering out duplicate files)
Write-Host "Export '$wim' to '$final'"

Try {
    Export-WindowsImage -SourceImagePath $wim -SourceIndex 1 -DestinationImagePath $final
} Catch {
    Write-Host "Export FAILED: [$($_.Exception.HResult)] $($_.Exception.Message)"
    Exit
}
