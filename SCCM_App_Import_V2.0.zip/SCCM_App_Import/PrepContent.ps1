﻿$MSIContentPath = "I:\Source\AppImport\MSI"
$EXEContentPath = "I:\Source\AppImport\EXE"
$AppImport = Import-Csv -Path C:\Users\sschmidt\Documents\SCCM_App_Import\ProdApplicationMapping.csv -Delimiter ","
ForEach($App in $AppImport)
{
    $ApplicationName = $app.ApplicationName
    $ApplicationPath = $app.Path
    $ApplicationType = $app.Type
    If($ApplicationType -eq "MSI")
    {
        Write-Host $ApplicationName $ApplicationPath $ApplicationType
        Copy-Item -Path $ApplicationPath -Destination $MSIContentPath -Force -Recurse
    }
    

}