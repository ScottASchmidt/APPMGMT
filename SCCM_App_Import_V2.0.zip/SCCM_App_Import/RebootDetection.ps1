﻿#HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired
$RebootNeeded = Test-Path 'hklm:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
If($RebootNeeded -eq $false)
{
    ### If Value is false that means the reg key was not found and we do not need to reboot and can exit
    Exit 0
}
else
{
    ### If Value is true that means the reg key was found and we need to reboot due to patching
    Exit 1
}