﻿param(
[parameter(Mandatory=$false)][ValidateNotNullOrEmpty()][String]$MDTDeploymentPath,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$SourcePath,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$TargetPath,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$IntuneUserName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$TenantName,
[parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][ValidateSet("SCCM", "MDT", "Intune")][String]$IntergrationBackend
)

### Must Install Win32App and Office Online Cmdlets for Intune Functionality
#Install-Module -Name IntuneWin32App -RequiredVersion 1.1.0
#Install-Module MSOnline
### MDT CMDlet installation
# Import-Module ".\bin\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
#excelin.onmicrosoft.com

### Function to Authenticate Against Intune
function Get-AuthToken
{
    [cmdletbinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        $User
    )

    $userUpn = New-Object "System.Net.Mail.MailAddress" -ArgumentList $User
    $tenant = $userUpn.Host

    Write-Host "Checking for AzureAD module..."

    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($AadModule -eq $null)
    {
        Write-Host "AzureAD PowerShell module not found, looking for AzureADPreview"
        $AadModule = Get-Module -Name "AzureADPreview" -ListAvailable
    }

    if ($AadModule -eq $null) {
        write-host
        write-host "AzureAD Powershell module not installed..." -f Red
        write-host "Install by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt" -f Yellow
        write-host "Script can't continue..." -f Red
        write-host
        exit
    }

    # Getting path to ActiveDirectory Assemblies
    # If the module count is greater than 1 find the latest version

    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
        $aadModule = $AadModule | ? { $_.version -eq $Latest_Version.version }
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    else {
        $adal = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
    }

    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    $clientId = "d1ddf0e4-d672-4dae-b554-9d5bdfd93547"
    $redirectUri = "urn:ietf:wg:oauth:2.0:oob"
    $resourceAppIdURI = "https://graph.microsoft.com"
    $authority = "https://login.microsoftonline.com/$Tenant"

    try {
        $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
        # https://msdn.microsoft.com/library/azure/microsoft.identitymodel.clients.activedirectory.promptbehavior.aspx
        # Change the prompt behaviour to force credentials each time: Auto, Always, Never, RefreshSession
        $platformParameters = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters" -ArgumentList "Auto"
        $userId = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserIdentifier" -ArgumentList ($User, "OptionalDisplayableId")
        $authResult = $authContext.AcquireTokenAsync($resourceAppIdURI, $clientId, $redirectUri, $platformParameters, $userId).Result
        # If the accesstoken is valid then create the authentication header
        if ($authResult.AccessToken) {
            # Creating header for Authorization token
            $authHeader = @{
                'Content-Type' = 'application/json'
                'Authorization' = "Bearer " + $authResult.AccessToken
                'ExpiresOn' = $authResult.ExpiresOn
            }
            return $authHeader
        }
        else {
            Write-Host
            Write-Host "Authorization Access Token is null, please re-run authentication..." -ForegroundColor Red
            Write-Host
            break
        }
    }
    catch {
        write-host $_.Exception.Message -f Red
        write-host $_.Exception.ItemName -f Red
        write-host
        break
    }   
}



### Connecting to Azure AD and MSOL if Intune is Selected
If($IntergrationBackend -eq "Intune")
{
    Install-Module -Name IntuneWin32App -RequiredVersion 1.1.0
    <#
    $authToken = Get-AuthToken -User $IntuneUserName

    try
    {
        $uri = "https://graph.microsoft.com/beta/me/managedDevices"
        Write-Verbose $uri
        (Invoke-RestMethod -Uri $uri –Headers $authToken –Method Get).Value
    }
    catch
    {
        $ex = $_.Exception
        $errorResponse = $ex.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd();
        Write-Host "Response content:`n$responseBody" -f Red
        Write-Error "Request to $Uri failed with HTTP Status $($ex.Response.StatusCode) $($ex.Response.StatusDescription)"
        write-host
        break
    }
    #>
   
}

If($IntergrationBackend -eq "MDT")
{
    ### Validating MDT Deployment Share Variable was populated
    If($MDTDeploymentPath -eq ""){$MDTDeploymentPath = Read-Host "Please enter the path to the MDT Deployment Share"}
    $ValidateDeploymentShare = Test-Path $MDTDeploymentPath
    If($ValidateDeploymentShare -eq $false)
    {
        DO
        {
            $MDTDeploymentPath = Read-Host "Please enter the path to the MDT Deployment Share"
            $ValidateDeploymentShare = Test-Path $MDTDeploymentPath
        }Until($ValidateDeploymentShare -eq $true)
    }
}
### Setting Current Working Directory
$TemplatePath = $PSScriptRoot
[System.IO.FileInfo]$MSISourcePath = $SourcePath + "\MSI"
[System.IO.FileInfo]$EXESourcePath = $SourcePath + "\EXE"

### Setting MSI DB Object
$WindowsInstaller = New-Object -ComObject WindowsInstaller.Installer

### Setting Template File
$InstallTemplateFile = $TemplatePath +"\Install_Template.cmd"
$UninstallTemplateFile = $TemplatePath +"\Uninstall_Template.cmd"

### Enumerating MSI Files from path directories
$MSIDirectory = Get-ChildItem -Path $MSISourcePath -Filter *.msi -Recurse
$EXEDirectory = Get-ChildItem -Path $EXESourcePath -Recurse -Filter Parameters.txt

### Connecting to SCCM
Function ConnectSCCM
{
    # Site configuration
    $SiteCode = "SITE CODE" # Site code 
    $ProviderMachineName = "PrimarySiteServerName" # SMS Provider machine name
    $initParams = @{}
    if((Get-Module ConfigurationManager) -eq $null) {Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams}
    if((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null) {New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams}
    # Set the current location to be the site code.
    Set-Location "$($SiteCode):\" @initParams
}

### Replacing Spaces and Commas
Function ReplaceSpecialChars($String)
{
    [String]$String = $String
    $String = $String.Trim()
    $String = $String.Replace(' ','_')
    $String = $String.Replace('__ ','_')
    $String = $String.Replace(',','')
    $String = $String.Replace('(','_')
    $String = $String.Replace(')','')
    $String = $String.Replace('®','')
    $String = $String.Replace('-','')
    $String = $String.Replace('__','_')
    $String = $String.Replace('Inc.','Inc')
    $String = $String.Replace('.msi','')
    $String = $String.Replace('/','')
    $String = $String.Replace('\','')
    Return $String
}

### Retrieving MSI Properties
Function RetrieveMSIProperty($PropertyName)
{
    $Query = "SELECT Value FROM Property WHERE Property = '$($PropertyName)'"
    $Global:View = $MSIDatabase.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $MSIDatabase, ($Query))
    $Global:View.GetType().InvokeMember("Execute", "InvokeMethod", $null, $Global:View, $null)
    $Record = $Global:View.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $Global:View, $null)
    $Value = $Record.GetType().InvokeMember("StringData", "GetProperty", $null, $Record, 1)
    return $Value
}

ForEach($MSI in $MSIDirectory)
{
     $SourceMSIDir = $MSI.DirectoryName
     $PathtoMSI = $MSI.FullName
     [string]$MSIName = $MSI.Name
     $MSINameForScript = $MSI.Name
     $MSIName = ReplaceSpecialChars($MSIName)

     ### Creating MSI Database Object
     $MSIDatabase = $WindowsInstaller.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $WindowsInstaller, @($PathtoMSI,0))

     [string]$ProductCode = RetrieveMSIProperty("ProductCode")
     $ProductCode = $ProductCode.Trim()
     [string]$ProductVersion = RetrieveMSIProperty("ProductVersion")
     [string]$Manufacturer = RetrieveMSIProperty("Manufacturer")
     [string]$ProductLanguage = RetrieveMSIProperty("ProductLanguage")
     [string]$ProductName = RetrieveMSIProperty("ProductName")
     $ManufacturerFolder = ReplaceSpecialChars($Manufacturer)
     $ProductNameFolder = ReplaceSpecialChars($ProductName)
     $ProductVersionFolder = ReplaceSpecialChars($ProductVersion)
     
     ### Creating New Target MSI Folder and Populating with Source Data
     $TargetAppFolder = $TargetPath + "\" + $ManufacturerFolder + "\" + $ProductNameFolder + "_" + $ProductVersionFolder
     
     ### Creating Intune Package Library Directory
     If($IntergrationBackend -eq "Intune")
     {
         $IntuneTargetPath = $TargetPath + "\IntuneLibrary\" + $ManufacturerFolder + "\" + $ProductNameFolder + "_" + $ProductVersionFolder
         $IntuneTargetPathExist = Test-Path $IntuneTargetPath
         If($IntuneTargetPathExist -eq $false)
         {      
             ### Creating New Intune Application Target Directory
             New-Item -ItemType Directory -Path $IntuneTargetPath -Force
         }
     }
     
     $InstallScriptFile = $TargetAppFolder + "\Install_" + $MSIName + ".cmd"
     $UninstallScriptFile = $TargetAppFolder + "\Uninstall_" + $MSIName + ".cmd"
     $InstallScriptFileName = "Install_" + $MSIName + ".cmd"
     $UninstallScriptFileName = "Uninstall_" + $MSIName + ".cmd"
     $AppNameVariable =  $ProductNameFolder + "." + $ProductVersionFolder
     $DateVar = Get-Date
     ### Checking if Directory already exists - if not create it
     $TargetAppFolderExist = Test-Path $TargetAppFolder
     If($TargetAppFolderExist -eq $false)
     {      
         ### Creating New Application Target Directory
         New-Item -ItemType Directory -Path $TargetAppFolder -Force
         
         ### Copying Content to target directory
         Copy-Item -Path "$SourceMSIDir\*" -Destination $TargetAppFolder -Recurse -exclude "*.cmd"

         [String]$TitleBlock = $Manufacturer + $ProductName + $ProductVersion
         $TitleBlock = $TitleBlock.Trim()
         $TitleBlock = $TitleBlock.Replace('  ',' ')

         ### Creating Install Script
         ((Get-Content -path $InstallTemplateFile -Raw) -replace 'APPINFOVAR',$TitleBlock) | Set-Content -Path $InstallScriptFile
         ((Get-Content -path $InstallScriptFile -Raw) -replace 'USERNAMEVAR',$env:USERNAME) | Set-Content -Path $InstallScriptFile
         ((Get-Content -path $InstallScriptFile -Raw) -replace 'CREATEDVAR',$DateVar) | Set-Content -Path $InstallScriptFile
         ((Get-Content -path $InstallScriptFile -Raw) -replace 'APPNAMEVAR',$AppNameVariable) | Set-Content -Path $InstallScriptFile
         
         ### Creating Start of Install String
         $InstallString = 'MSIEXEC /i "%CDIR%' + $MSINameForScript + '" '
         
         ### Looking for MSP Files
         $MSPDirectory = Get-ChildItem -Path $TargetAppFolder -Filter *.msp
         IF($MSPDirectory -ne $null){$InstallString = $InstallString + '/Update "%CDIR%' + $MSPDirectory.Name + '" '}
         
         ### Looking for MST Files
         $MSTDirectory = Get-ChildItem -Path $TargetAppFolder -Filter *.mst
         IF($MSTDirectory -ne $null){$InstallString = $InstallString + 'TRANSFORMS="%CDIR%' + $MSTDirectory.Name + '" '}
         
         ### Adding Closing Arguments and Updating the Command File
         $InstallString = $InstallString + '/qb /l* %MSILogFile% /norestart'
         ((Get-Content -path $InstallScriptFile -Raw) -replace 'INSTALLSTRING',$InstallString) | Set-Content -Path $InstallScriptFile

         #Write-host $ProductCode $ProductVersion $ProductLanguage $Manufacturer $ProductName

         ### Creating Uninstall Script
         ((Get-Content -path $UninstallTemplateFile -Raw) -replace 'APPINFOVAR',$TitleBlock) | Set-Content -Path $UninstallScriptFile
         ((Get-Content -path $UninstallScriptFile -Raw) -replace 'USERNAMEVAR',$env:USERNAME) | Set-Content -Path $UninstallScriptFile
         ((Get-Content -path $UninstallScriptFile -Raw) -replace 'CREATEDVAR',$DateVar) | Set-Content -Path $UninstallScriptFile
         ((Get-Content -path $UninstallScriptFile -Raw) -replace 'APPNAMEVAR',$AppNameVariable) | Set-Content -Path $UninstallScriptFile
         ((Get-Content -path $UninstallScriptFile -Raw) -replace 'GUIDVAR',$ProductCode.trim()) | Set-Content -Path $UninstallScriptFile

         If($IntergrationBackend -eq "SCCM")
         {
             $ProductCode = $ProductCode.Replace(' ','')
             ConnectSCCM
             ### Checking to see if Application already exists - If it does skip it
             $AppProductName = $ProductName + " " + $ProductVersion
             $AppCheck = Get-CMApplication -Name $AppProductName
             If($AppCheck -eq $null)
             {
                 New-CMApplication -ReleaseDate $DateVar -Name $AppProductName -Publisher $Manufacturer -SoftwareVersion $ProductVersion -Description "$ProductName $Manufacturer $ProductVersion" -AutoInstall $true
                 Add-CMScriptDeploymentType -InstallationBehaviorType InstallForSystem -LogonRequirementType WhetherOrNotUserLoggedOn -UserInteractionMode Hidden -ApplicationName $AppProductName -DeploymentTypeName "Deploy $AppProductName" -ProductCode $ProductCode -ContentLocation $TargetAppFolder -InstallCommand $InstallScriptFileName -UninstallCommand $UninstallScriptFileName -SourceUpdateProductCode $ProductCode
                 Write-host "SCCM BackEnd Selected"
                 set-Location "$TemplatePath"
             }
         }
         If($IntergrationBackend -eq "Intune")
         {
            
             Write-Host "Customize Command Script if necessary"
             Pause
             Start-Process "$TemplatePath\IntuneWinAppUtil.exe" -ArgumentList "-c $TargetAppFolder -s $MSINameForScript -o $IntuneTargetPath -q" -Wait
             $IntuneWIMFileName = (Get-ChildItem -Path $IntuneTargetPath -Filter *.intunewin).FullName
             $DisplayName = $Manufacturer + " " + $ProductName + " " + $ProductVersion
             $DetectionRule = New-IntuneWin32AppDetectionRule -MSI -MSIProductCode $ProductCode
             $RequirementRule = New-IntuneWin32AppRequirementRule -Architecture All -MinimumSupportedOperatingSystem 1607
             $InstallCommandLine = $InstallScriptFileName
             $UninstallCommandLine = $UninstallScriptFileName
             $Global:authToken = Get-AuthToken -User $IntuneUserName
             Add-IntuneWin32App -TenantName $TenantName -FilePath $IntuneWIMFileName -DisplayName $DisplayName -Description $DisplayName -Publisher $Manufacturer -InstallExperience system -RestartBehavior suppress -DetectionRule $DetectionRule -RequirementRule $RequirementRule -InstallCommandLine $InstallCommandLine -UninstallCommandLine $UninstallCommandLine -Verbose
         }
         
         If($IntergrationBackend -eq "MDT")
         {
             New-PSDrive -Name "DS001" -PSProvider MDTProvider -Root $MDTDeploymentPath
             
             $DisplayName = $Manufacturer + " " + $ProductName + " " + $ProductVersion
             $DestinationFolder = $Manufacturer + "_" + $ProductNameFolder + "_" + $ProductVersionFolder
             $InstallCommandLine = $InstallScriptFileName
             Import-MDTApplication -path "DS001:\Applications" -enable "True" -Name $DisplayName -ShortName $ProductName -Version $ProductVersion -Publisher $Manufacturer -Language "EN" -CommandLine $InstallCommandLine -WorkingDirectory ".\Applications\$DestinationFolder" -ApplicationSourcePath $TargetAppFolder -DestinationFolder $DestinationFolder
             Pause
         }

     }

     # Commit database and close view
     $MSIDatabase.GetType().InvokeMember("Commit", "InvokeMethod", $null, $MSIDatabase, $null)
     $Global:View.GetType().InvokeMember("Close", "InvokeMethod", $null, $Global:View, $null)           
     $MSIDatabase = $null
     $Global:View = $null
}

ForEach($EXEParamFile in $EXEDirectory)
{
    $TargetAppFolder = $TargetPath + "\" + $ManufacturerFolder + "\" + $ProductNameFolder + "_" + $ProductVersionFolder
    #Write-Host $TargetAppFolder
    #Pause
    $InstallScriptFile = $TargetAppFolder + "\Install_" + $MSIName + ".cmd"
    $UninstallScriptFile = $TargetAppFolder + "\Uninstall_" + $MSIName + ".cmd"
    $InstallScriptFileName = "Install_" + $MSIName + ".cmd"
    $UninstallScriptFileName = "Uninstall_" + $MSIName + ".cmd"
    $AppNameVariable =  $ProductNameFolder + "." + $ProductVersionFolder
    $DateVar = Get-Date
    ### Checking if Directory already exists - if not create it
    $TargetAppFolderExist = Test-Path $TargetAppFolder
    $EXEParamFile.fullname
    $InstallParams = (Get-Content -Path $EXEParamFile.fullname -TotalCount 2)[-1]
    Write-Host $InstallParams
    If($IntergrationBackend -eq "SCCM")
    {
        ConnectSCCM
        $DetectionType = (Get-Content -Path $EXEParamFile.fullname -TotalCount 5)[-1]
        If($DetectionType -eq "MSI")
        {
            $ProductCode = (Get-Content -Path $EXEParamFile.fullname -TotalCount 8)[-1]
            $DetectionMethod = New-CMDetectionClauseWindowsInstaller -ProductCode $ProductCode
            Write-Host $ProductCode
        }

        If($DetectionType -eq "RegistryKey")
        {
            $Hive = (Get-Content -Path $EXEParamFile.fullname -TotalCount 11)[-1]
            $Key = (Get-Content -Path $EXEParamFile.fullname -TotalCount 11)[-1]
            $DetectionMethod = New-CMDetectionClauseRegistryKey -Existence -Hive $Hive -KeyName $Key
            Write-Host $Key $Hive
        }

        If($DetectionType -eq "RegistryValue")
        {
            $Hive = (Get-Content -Path $EXEParamFile.fullname -TotalCount 15)[-1]
            $Key = (Get-Content -Path $EXEParamFile.fullname -TotalCount 16)[-1]
            $Value = (Get-Content -Path $EXEParamFile.fullname -TotalCount 17)[-1]
            $Data = (Get-Content -Path $EXEParamFile.fullname -TotalCount 18)[-1]
            $DetectionMethod =  New-CMDetectionClauseRegistryKeyValue -ExpressionOperator Contains -Hive $Hive -KeyName $Key -ValueName $Value -PropertyType String -ExpectedValue $Data
            Write-Host $key $Value $Data
        }
    
        If($DetectionType -eq "File")
        {
            $Path = (Get-Content -Path $EXEParamFile.fullname -TotalCount 21)[-1]
            $File = (Get-Content -Path $EXEParamFile.fullname -TotalCount 22)[-1]
            #$Version = (Get-Content -Path $EXEParamFile.fullname -TotalCount 23)[-1]
            $DetectionMethod = New-CMDetectionClauseFile -Path $Path -FileName $File -Existence
            Write-Host $Path $File $Version
        }

        If($DetectionType -eq "Directory")
        {
            $Path = (Get-Content -Path $EXEParamFile.fullname -TotalCount 26)[-1]
            $DirectoryName = (Get-Content -Path $EXEParamFile.fullname -TotalCount 27)[-1]
            $DetectionMethod = New-CMDetectionClauseDirectory -Path $Path -DirectoryName $DirectoryName -Existence
            Write-Host $Path
        }

        New-CMApplication -ReleaseDate $DateVar -Name $ProductName -Publisher $Manufacturer -SoftwareVersion $ProductVersion -Description "$ProductName $Manufacturer $ProductVersion" -AutoInstall $true
        Add-CMScriptDeploymentType -InstallationBehaviorType InstallForSystem -LogonRequirementType WhetherOrNotUserLoggedOn -UserInteractionMode Hidden -ApplicationName $ProductName -DeploymentTypeName "Deploy $ProductName" -ProductCode $ProductCode -ContentLocation $TargetAppFolder -InstallCommand $InstallScriptFileName -UninstallCommand $UninstallScriptFileName -SourceUpdateProductCode $ProductCode
    }
}